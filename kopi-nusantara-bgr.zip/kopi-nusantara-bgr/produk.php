<?php
/** Halaman Produk (dengan filter kategori) */
$judul = 'Produk';
$aktif = 'produk';
require __DIR__ . '/includes/header.php';

$kategoriList = ambilKategori();
$kategoriId   = filter_input(INPUT_GET, 'kategori', FILTER_VALIDATE_INT) ?: null;
$cari         = mb_substr(trim($_GET['q'] ?? ''), 0, 60);
$daftarProduk = ambilProduk($kategoriId, null, $cari);
?>

<header class="page-header text-center" style="<?= e(bannerStyle('kopi-7.jpg')) ?>">
    <div class="container">
        <h1 class="fw-bold animate__animated animate__fadeInDown">Produk Kami</h1>
        <p class="mb-0">Kopi kemasan dan minuman siap saji pilihan</p>
    </div>
</header>

<main class="container py-5">
    <!-- Pencarian nama produk -->
    <form method="get" action="produk.php" class="row justify-content-center mb-3" role="search">
        <?php if ($kategoriId): ?><input type="hidden" name="kategori" value="<?= (int) $kategoriId ?>"><?php endif; ?>
        <div class="col-md-8 col-lg-6">
            <div class="input-group">
                <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="<?= e($cari) ?>" maxlength="60" class="form-control"
                       placeholder="Cari nama produk, contoh: gayo, latte, bubuk" aria-label="Cari nama produk">
                <button type="submit" class="btn btn-kopi">Cari</button>
                <?php if ($cari !== ''): ?>
                    <a href="produk.php<?= $kategoriId ? '?kategori=' . (int) $kategoriId : '' ?>" class="btn btn-outline-kopi" title="Hapus pencarian">Reset</a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <!-- Filter kategori -->
    <div class="d-flex flex-wrap justify-content-center gap-2 mb-4">
        <a href="produk.php<?= $cari !== '' ? '?q=' . urlencode($cari) : '' ?>" class="btn btn-sm <?= $kategoriId ? 'btn-outline-kopi' : 'btn-kopi' ?>">Semua</a>
        <?php foreach ($kategoriList as $k): ?>
            <a href="produk.php?kategori=<?= (int) $k['id'] ?><?= $cari !== '' ? '&amp;q=' . urlencode($cari) : '' ?>"
               class="btn btn-sm <?= $kategoriId === (int) $k['id'] ? 'btn-kopi' : 'btn-outline-kopi' ?>">
                <?= e($k['nama']) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <?php if ($cari !== '' && !empty($daftarProduk)): ?>
        <p class="text-center text-muted small mb-3"><?= count($daftarProduk) ?> produk ditemukan untuk &quot;<?= e($cari) ?>&quot;</p>
    <?php endif; ?>

    <?php if (empty($daftarProduk)): ?>
        <div class="alert alert-warning text-center">
            <?= $cari !== '' ? 'Produk dengan nama &quot;' . e($cari) . '&quot; tidak ditemukan.' : 'Belum ada produk pada kategori ini.' ?>
        </div>
    <?php else: ?>
        <div class="row g-4" id="gridProduk">
            <?php foreach ($daftarProduk as $urut => $p): ?>
                <div class="col-12 col-sm-6 col-lg-4">
                    <?php include __DIR__ . '/includes/kartu_produk.php'; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php include __DIR__ . '/includes/bagian_ulasan.php'; ?>
    <?php include __DIR__ . '/includes/bagian_asal.php'; ?>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
