<?php
/**
 * Fungsi bantu yang dipakai bersama oleh halaman publik dan admin.
 */
require_once __DIR__ . '/../config/koneksi.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Escape output agar aman dari XSS. */
function e(?string $teks): string
{
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

/** Format angka menjadi Rupiah, contoh: Rp 85.000 */
function rupiah(int $angka): string
{
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

/** Simpan pesan sekali tampil (flash message). */
function setFlash(string $tipe, string $pesan): void
{
    $_SESSION['flash'] = ['tipe' => $tipe, 'pesan' => $pesan];
}

/** Ambil lalu hapus flash message. */
function getFlash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

/** Token CSRF untuk melindungi form POST. */
function csrfToken(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrfToken()) . '">';
}

/** Hentikan eksekusi jika token CSRF tidak cocok. */
function csrfCheck(): void
{
    $kirim = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $kirim)) {
        http_response_code(419);
        exit('Sesi tidak valid. Muat ulang halaman lalu coba lagi.');
    }
}

/** Alihkan ke URL lain lalu berhenti. */
function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/** Label dan warna badge untuk status pesanan (memakai switch). */
function infoStatus(string $status): array
{
    switch ($status) {
        case 'baru':     return ['Baru', 'secondary'];
        case 'diproses': return ['Diproses', 'info'];
        case 'dikirim':  return ['Dikirim', 'primary'];
        case 'selesai':  return ['Selesai', 'success'];
        case 'batal':    return ['Batal', 'danger'];
        default:         return [ucfirst($status), 'dark'];
    }
}

const STATUS_PESANAN = ['baru', 'diproses', 'dikirim', 'selesai', 'batal'];

/** Ambil produk beserta nama kategorinya. */
function ambilProduk(?int $kategoriId = null, ?int $limit = null, string $cari = ''): array
{
    $sql = 'SELECT p.*, k.nama AS kategori
            FROM produk p JOIN kategori k ON k.id = p.kategori_id';
    $param = [];
    $syarat = [];
    if ($kategoriId) {
        $syarat[] = 'p.kategori_id = ?';
        $param[] = $kategoriId;
    }
    if ($cari !== '') {
        // Cari di nama produk; karakter khusus LIKE di-escape
        $syarat[] = 'p.nama LIKE ?';
        $param[] = '%' . addcslashes($cari, '%_\\') . '%';
    }
    if ($syarat) {
        $sql .= ' WHERE ' . implode(' AND ', $syarat);
    }
    $sql .= ' ORDER BY p.id ASC';
    if ($limit) {
        $sql .= ' LIMIT ' . (int) $limit;
    }
    $stmt = db()->prepare($sql);
    $stmt->execute($param);
    return $stmt->fetchAll();
}

function ambilKategori(): array
{
    return db()->query('SELECT * FROM kategori ORDER BY nama')->fetchAll();
}

/**
 * Akun media sosial. Ganti URL dengan akun asli Kopi NusantaraBogor.
 * Format: [nama, kelas ikon Bootstrap Icons, URL]
 */
const SOSMED = [
    ['Instagram', 'bi-instagram',  'https://www.instagram.com/kopinusantarabogor'],
    ['TikTok',    'bi-tiktok',     'https://www.tiktok.com/@kopinusantarabogor'],
    ['Facebook',  'bi-facebook',   'https://www.facebook.com/kopinusantarabogor'],
    ['X',         'bi-twitter-x',  'https://x.com/kopinusantarabogor'],
];

/** Nomor WhatsApp kedai (format internasional tanpa +). Ganti dengan nomor asli. */
const WA_NOMOR = '6281200001234';

/**
 * Daftar promo. Dipakai oleh banner berjalan, panel "Klaim Promo" di halaman
 * Pesan, dan perhitungan total. Ubah/tambah promo hanya di sini.
 * tipe: 'persen' (nilai = persen diskon) atau 'potongan' (nilai = rupiah)
 * min: minimal belanja (rupiah); kategori: nama kategori atau null (semua produk)
 */
const PROMO = [
    'KOPI10'    => ['judul' => 'Diskon 10% semua produk', 'tipe' => 'persen',   'nilai' => 10,    'min' => 50000,  'kategori' => null],
    'MINUMAN15' => ['judul' => 'Diskon 15% Minuman Siap Saji', 'tipe' => 'persen', 'nilai' => 15, 'min' => 40000,  'kategori' => 'Minuman Siap Saji'],
    'HEMAT10K'  => ['judul' => 'Potongan Rp 10.000', 'tipe' => 'potongan', 'nilai' => 10000, 'min' => 100000, 'kategori' => null],
];

/** Hitung diskon promo. Mengembalikan [diskon (int), pesan galat atau null]. */
function hitungPromo(string $kode, array $produk, int $subtotal): array
{
    $kode = strtoupper(trim($kode));
    if ($kode === '') {
        return [0, null];
    }
    $p = PROMO[$kode] ?? null;
    if (!$p) {
        return [0, 'Kode promo tidak dikenal.'];
    }
    if ($p['kategori'] !== null && ($produk['kategori'] ?? '') !== $p['kategori']) {
        return [0, 'Kode ini hanya berlaku untuk ' . $p['kategori'] . '.'];
    }
    if ($subtotal < $p['min']) {
        return [0, 'Minimal belanja ' . rupiah($p['min']) . ' untuk kode ini.'];
    }
    $diskon = $p['tipe'] === 'persen' ? intdiv($subtotal * $p['nilai'], 100) : min($p['nilai'], $subtotal);
    return [$diskon, null];
}

/** Cetak deretan ikon sosial media. $gaya: 'terang' (footer) atau 'kopi' (halaman). */
function ikonSosmed(string $gaya = 'terang'): string
{
    $html = '<div class="sosmed sosmed-' . e($gaya) . '">';
    foreach (SOSMED as [$nama, $ikon, $url]) {
        $html .= '<a href="' . e($url) . '" target="_blank" rel="noopener noreferrer" '
               . 'aria-label="' . e($nama) . ' Kopi NusantaraBogor" title="' . e($nama) . '">'
               . '<i class="bi ' . e($ikon) . '"></i></a>';
    }
    return $html . '</div>';
}

/** Kalimat singkat status pesanan untuk notifikasi. */
function pesanStatus(string $status): string
{
    switch ($status) {
        case 'baru':     return 'sudah kami terima';
        case 'diproses': return 'sedang diproses';
        case 'dikirim':  return 'sedang dikirim';
        case 'selesai':  return 'sudah selesai';
        case 'batal':    return 'dibatalkan';
        default:         return 'diperbarui';
    }
}

/* ---------------------------------------------------------------
 * Pembayaran: QRIS atau transfer bank (verifikasi manual oleh admin).
 * Alur: pemesan memilih metode -> struk langsung tampil di riwayat
 * pesanan (status "Belum dibayar") -> pemesan membayar & unggah bukti
 * (status "Menunggu verifikasi") -> admin konfirmasi (status "Lunas").
 * ------------------------------------------------------------- */

/**
 * Rekening bank tujuan transfer. GANTI dengan rekening asli kedai
 * (nomor di bawah hanya contoh). Tambah/hapus baris sesuai kebutuhan.
 */
const REKENING = [
    'BCA'     => ['no' => '1234567890',      'atas_nama' => 'Kopi NusantaraBogor'],
    'BRI'     => ['no' => '0123-01-000123-50-1', 'atas_nama' => 'Kopi NusantaraBogor'],
    'Mandiri' => ['no' => '1230001234567',   'atas_nama' => 'Kopi NusantaraBogor'],
];

/** Nama merchant yang tertera pada QRIS. */
const QRIS_NAMA = 'Kopi NusantaraBogor';

const METODE_BAYAR = ['qris' => 'QRIS', 'transfer' => 'Transfer Bank'];
const STATUS_BAYAR = ['belum', 'menunggu', 'lunas'];

/**
 * URL gambar QRIS kedai. Unggah gambar QRIS asli dengan nama
 * assets/img/qris.png (atau .jpg / .webp); bila tidak ada, dipakai
 * gambar penanda assets/img/qris-contoh.svg.
 */
function qrisUrl(): string
{
    foreach (['png', 'jpg', 'jpeg', 'webp'] as $ext) {
        if (is_file(__DIR__ . '/../assets/img/qris.' . $ext)) {
            return 'assets/img/qris.' . $ext;
        }
    }
    return 'assets/img/qris-contoh.svg';
}

/** Label dan warna badge status pembayaran: [label, warna Bootstrap]. */
function infoBayar(string $status): array
{
    switch ($status) {
        case 'belum':    return ['Belum dibayar', 'warning'];
        case 'menunggu': return ['Menunggu verifikasi', 'info'];
        case 'lunas':    return ['Lunas', 'success'];
        default:         return [ucfirst($status), 'dark'];
    }
}

/** Nomor struk, contoh: INV-20261121-0007. */
function noStruk(array $r): string
{
    return 'INV-' . date('Ymd', strtotime($r['created_at'])) . '-' . str_pad((string) (int) $r['id'], 4, '0', STR_PAD_LEFT);
}

/** Nama tampilan metode bayar, contoh "Transfer Bank BCA" atau "QRIS". */
function labelMetode(array $r): string
{
    $label = METODE_BAYAR[$r['metode_bayar']] ?? ucfirst((string) $r['metode_bayar']);
    return ($r['metode_bayar'] === 'transfer' && $r['bank'] !== '') ? $label . ' ' . $r['bank'] : $label;
}

/**
 * Simpan foto bukti pembayaran ke assets/img/uploads/bukti.
 * Mengembalikan nama file. Melempar RuntimeException bila tidak valid.
 */
function simpanBukti(array $file, int $idPesanan): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('Pilih foto bukti pembayaran terlebih dahulu.');
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Unggahan gagal. Coba lagi dengan file yang lebih kecil.');
    }
    if ($file['size'] > 3 * 1024 * 1024) {
        throw new RuntimeException('Ukuran bukti maksimal 3 MB.');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $izin = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($izin[$mime])) {
        throw new RuntimeException('Bukti harus berupa gambar JPG, PNG, atau WEBP.');
    }
    $folder = __DIR__ . '/../assets/img/uploads/bukti';
    if (!is_dir($folder) && !mkdir($folder, 0755, true) && !is_dir($folder)) {
        throw new RuntimeException('Folder bukti tidak dapat dibuat. Periksa izin folder uploads.');
    }
    $nama = 'bukti-' . $idPesanan . '-' . bin2hex(random_bytes(6)) . '.' . $izin[$mime];
    if (!move_uploaded_file($file['tmp_name'], $folder . '/' . $nama)) {
        throw new RuntimeException('Bukti tidak dapat disimpan. Periksa izin folder uploads.');
    }
    return $nama;
}

/** Hapus file bukti dari disk (diam bila tidak ada). */
function hapusBukti(string $nama): void
{
    if ($nama !== '' && preg_match('/^bukti-[\w.-]+$/', $nama)) {
        @unlink(__DIR__ . '/../assets/img/uploads/bukti/' . $nama);
    }
}

/* ---------------------------------------------------------------
 * Pelacakan pesanan TANPA akun/login.
 * - Tiap pesanan punya kode_lacak acak (8 karakter) di database.
 * - Peramban pemesan mengingat pesanannya lewat cookie "id.kode".
 * - Dari perangkat lain: cek dengan nomor pesanan + nomor telepon.
 * ------------------------------------------------------------- */
const COOKIE_PESANAN = 'pesanan_kopi';

/** Kode acak untuk pesanan baru. */
function kodeLacakBaru(): string
{
    return bin2hex(random_bytes(4));
}

/** Baca cookie pesanan: [id => kode_lacak]. Format tidak valid diabaikan. */
function bacaCookiePesanan(): array
{
    $hasil = [];
    foreach (explode(',', (string) ($_COOKIE[COOKIE_PESANAN] ?? '')) as $item) {
        if (preg_match('/^(\d{1,10})\.([a-f0-9]{8})$/', $item, $m)) {
            $hasil[(int) $m[1]] = $m[2];
        }
    }
    return $hasil;
}

/** Simpan pesanan ke cookie peramban ini (terbaru di depan, maks. 20, 180 hari). */
function ingatPesanan(int $id, string $kode): void
{
    $daftar = bacaCookiePesanan();
    unset($daftar[$id]);
    $daftar = array_slice([$id => $kode] + $daftar, 0, 20, true);

    $nilai = [];
    foreach ($daftar as $i => $k) {
        $nilai[] = $i . '.' . $k;
    }
    $nilai = implode(',', $nilai);

    $_COOKIE[COOKIE_PESANAN] = $nilai;
    if (!headers_sent()) {
        setcookie(COOKIE_PESANAN, $nilai, [
            'expires'  => time() + 60 * 60 * 24 * 180,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
}

/** Pesanan yang diingat peramban ini (sudah dicocokkan dengan kode di database). */
function pesananPeramban(): array
{
    $ingat = bacaCookiePesanan();
    if (!$ingat) {
        return [];
    }
    $tanda = implode(',', array_fill(0, count($ingat), '?'));
    $stmt  = db()->prepare(
        'SELECT ps.*, p.nama AS produk, pl.nama AS nama_pemesan, pl.alamat, pl.telepon
         FROM pesanan ps
         JOIN produk p ON p.id = ps.produk_id
         JOIN pelanggan pl ON pl.id = ps.pelanggan_id
         WHERE ps.id IN (' . $tanda . ') ORDER BY ps.id DESC'
    );
    $stmt->execute(array_keys($ingat));

    return array_values(array_filter($stmt->fetchAll(), static function (array $r) use ($ingat): bool {
        return $r['kode_lacak'] !== '' && hash_equals($r['kode_lacak'], $ingat[(int) $r['id']] ?? '');
    }));
}

/** Samakan format telepon: hanya angka, awalan 62 menjadi 0. */
function normalisasiTelepon(string $telepon): string
{
    $angka = preg_replace('/\D+/', '', $telepon);
    if (str_starts_with($angka, '62')) {
        $angka = '0' . substr($angka, 2);
    }
    return $angka;
}

/** Cari pesanan lewat nomor pesanan + nomor telepon pemesan (null bila tidak cocok). */
function cariPesanan(int $id, string $telepon): ?array
{
    $stmt = db()->prepare(
        'SELECT ps.*, p.nama AS produk, pl.telepon
         FROM pesanan ps
         JOIN produk p ON p.id = ps.produk_id
         JOIN pelanggan pl ON pl.id = ps.pelanggan_id
         WHERE ps.id = ?'
    );
    $stmt->execute([$id]);
    $r = $stmt->fetch();
    if (!$r || $r['kode_lacak'] === '') {
        return null;
    }
    $a = normalisasiTelepon($telepon);
    return ($a !== '' && hash_equals(normalisasiTelepon($r['telepon']), $a)) ? $r : null;
}

/** Tandai status pesanan sudah dilihat (menghilangkan notifikasi). */
function tandaiDilihat(array $idPesanan): void
{
    if (!$idPesanan) {
        return;
    }
    $tanda = implode(',', array_fill(0, count($idPesanan), '?'));
    db()->prepare('UPDATE pesanan SET status_dilihat = status WHERE id IN (' . $tanda . ')')
        ->execute(array_map('intval', $idPesanan));
}

/** Pesanan di peramban ini yang statusnya berubah sejak terakhir dilihat. */
function notifPesanan(): array
{
    return array_values(array_filter(pesananPeramban(), static function (array $r): bool {
        return $r['status'] !== $r['status_dilihat'];
    }));
}

/**
 * URL foto dari dua sumber bebas pakai:
 * nama file (.jpg/.png/.webp) = foto lokal di assets/img/galeri,
 * kode angka saja = Pexels (contoh '1581554'), selain itu = Unsplash.
 */
function urlFoto(string $id, int $lebar = 800): string
{
    // File lokal di assets/img/galeri (contoh: 'kopi-8.jpg')
    if (preg_match('/\.(jpe?g|png|webp)$/i', $id)) {
        return 'assets/img/galeri/' . $id;
    }
    if (ctype_digit($id)) {
        return "https://images.pexels.com/photos/{$id}/pexels-photo-{$id}.jpeg?auto=compress&cs=tinysrgb&w={$lebar}";
    }
    return "https://images.unsplash.com/photo-{$id}?auto=format&fit=crop&w={$lebar}&q=80";
}

/** Gaya inline untuk banner header halaman (foto latar). */
function bannerStyle(string $id): string
{
    return 'background-image:url(' . urlFoto($id, 1600) . ')';
}

/**
 * Daftar foto galeri. 'slug' = nama file di assets/img/galeri/.
 * Ganti dengan foto kedai sendiri: taruh file di folder itu lalu
 * tulis nama filenya (contoh: 'kedai-depan.jpg') pada 'slug'.
 */
function daftarGaleri(): array
{
    return [
        ['slug' => 'kopi-8.jpg',  'kategori' => 'Suasana', 'judul' => 'Ruang Kedai',
         'deskripsi' => 'Bar kayu dan lampu gantung yang menciptakan suasana hangat saat sore.'],
        ['slug' => 'kopi-5.jpg',  'kategori' => 'Barista', 'judul' => 'Menuang Susu',
         'deskripsi' => 'Barista menuang susu hangat untuk membentuk latte art di atas espresso.'],
        ['slug' => 'kopi-4.jpg',  'kategori' => 'Kopi',    'judul' => 'Tiga Latte Art',
         'deskripsi' => 'Tiga cangkir latte dengan motif daun dan bunga, dilihat dari atas.'],
        ['slug' => 'kopi-6.jpg',  'kategori' => 'Barista', 'judul' => 'Menggiling Biji',
         'deskripsi' => 'Biji kopi digiling segar sebelum diseduh agar aromanya maksimal.'],
        ['slug' => 'kopi-10.jpg', 'kategori' => 'Suasana', 'judul' => 'Meja Bar dan Mesin Espresso',
         'deskripsi' => 'Area bar dengan mesin espresso dan papan nama bernyala.'],
        ['slug' => 'kopi-2.jpg',  'kategori' => 'Kopi',    'judul' => 'Latte di Meja Kayu',
         'deskripsi' => 'Secangkir latte dengan motif daun di atas meja kayu.'],
        ['slug' => 'kopi-7.jpg',  'kategori' => 'Barista', 'judul' => 'Seduh Manual V60',
         'deskripsi' => 'Peralatan seduh manual: dripper, server kaca, dan teko leher angsa.'],
        ['slug' => 'kopi-13.jpg', 'kategori' => 'Kopi',    'judul' => 'Aneka Racikan',
         'deskripsi' => 'Kopi hitam, latte, dan espresso dalam satu meja.'],
        ['slug' => 'kopi-1.jpg',  'kategori' => 'Biji',    'judul' => 'Biji Kopi dan Kopi Hitam',
         'deskripsi' => 'Biji kopi sangrai di samping secangkir kopi hitam yang masih mengepul.'],
        ['slug' => 'kopi-11.jpg', 'kategori' => 'Kebun',   'judul' => 'Buah Kopi di Pohon',
         'deskripsi' => 'Buah kopi merah dan hijau yang sedang matang di cabangnya.'],
        ['slug' => 'kopi-12.webp', 'kategori' => 'Suasana', 'judul' => 'Sudut Kedai',
         'deskripsi' => 'Area duduk kedai dengan meja kayu dan tanaman di dekat jendela.'],
    ];
}

/** URL foto galeri: file lokal bila ada, selain itu lewat urlFoto(). */
function urlGaleri(string $slug, int $lebar = 800): string
{
    if (preg_match('/\.(jpe?g|png|webp)$/i', $slug) && is_file(__DIR__ . '/../assets/img/galeri/' . $slug)) {
        return 'assets/img/galeri/' . $slug;
    }
    return urlFoto($slug, $lebar);
}

/**
 * Daerah asal kopi. Data diringkas dari sumber terbuka (lihat 'sumber').
 * [nama, daerah, ketinggian, jenis, ciri, fakta, foto, sumber(label, url)]
 */
function daftarAsal(): array
{
    return [
        ['nama' => 'Gayo', 'daerah' => 'Aceh Tengah, Bener Meriah, Gayo Lues, Aceh',
         'tinggi' => '1.200 - 1.700 mdpl', 'jenis' => 'Arabika',
         'ciri' => 'Aroma kacang, karamel, dan buah; berlapis dan segar.',
         'fakta' => 'Dataran tinggi Gayo memiliki Indikasi Geografis dan menjadi jantung ekonomi ribuan keluarga petani kopi.',
         'foto' => 'asal-gayo.jpg',
         'sumber' => ['Good News From Indonesia', 'https://www.goodnewsfromindonesia.id/2025/04/30/kopi-gayo-tradisi-di-balik-kopi-arabika-terbaik-di-indonesia']],
        ['nama' => 'Flores Bajawa', 'daerah' => 'Kabupaten Ngada, Nusa Tenggara Timur',
         'tinggi' => '1.200 - 1.800 mdpl', 'jenis' => 'Arabika',
         'ciri' => 'Tumbuh di tanah vulkanik; karakter bersih dengan nuansa manis dan rempah.',
         'fakta' => 'Pernah meraih nilai 85,50 dari skala 100 dari Specialty Coffee Association dan telah bersertifikat Indikasi Geografis.',
         'foto' => 'asal-flores.jpg',
         'sumber' => ['Bank Indonesia', 'https://www.bi.go.id/id/publikasi/ruang-media/cerita-bi/Pages/business-matching-membuka-jalan-kopi-bajawa-ke-pasar-dunia.aspx']],
        ['nama' => 'Kintamani', 'daerah' => 'Kabupaten Bangli, Bali (lereng Gunung Batur)',
         'tinggi' => 'di atas 900 mdpl', 'jenis' => 'Arabika',
         'ciri' => 'Keasaman segar bernuansa jeruk dengan rasa pahit yang rendah.',
         'fakta' => 'Ditanam tumpang sari dengan jeruk dan dikelola kelompok tani Subak Abian. Menjadi kopi pertama Indonesia yang meraih Indikasi Geografis (2008).',
         'foto' => 'kopi-11.jpg',
         'sumber' => ['Mongabay Indonesia', 'https://mongabay.co.id/2021/03/20/mengani-desa-bibit-kopi-kintamani/']],
        ['nama' => 'Lampung', 'daerah' => 'Lampung Barat, Tanggamus, Way Kanan, Lampung Utara',
         'tinggi' => 'dataran rendah - menengah', 'jenis' => 'Robusta',
         'ciri' => 'Pahit kuat dengan aroma cokelat dan rempah; kafein lebih tinggi dari arabika.',
         'fakta' => 'Sentra robusta terbesar kedua di Indonesia setelah Sumatera Selatan, sekitar 17% produksi nasional (BPS, 2022).',
         'foto' => 'asal-lampung.jpg',
         'sumber' => ['Universitas Diponegoro (BPS 2022)', 'https://eprints2.undip.ac.id/id/eprint/24928/2/Skripsi%20Bagian%202.pdf']],
    ];
}

/**
 * Ulasan kopi dari tim Kopi NusantaraBogor. Skor 1-5 per aspek.
 * 'produk' harus sama dengan nama produk di database agar tombol Pesan muncul.
 */
function daftarUlasan(): array
{
    return [
        ['produk' => 'Kopi Gayo Aceh', 'asal' => 'Gayo, Aceh', 'sangrai' => 'Medium',
         'catatan' => 'Floral di awal, body tebal, ditutup after taste cokelat yang panjang.',
         'skor' => ['Aroma' => 5, 'Body' => 4, 'Keasaman' => 3, 'Manis' => 4], 'bintang' => 4.8,
         'cocok' => 'V60, French press, kopi tubruk halus'],
        ['produk' => 'Kopi Flores Bajawa', 'asal' => 'Bajawa, Flores', 'sangrai' => 'Medium',
         'catatan' => 'Karamel dan rempah dengan keasaman lembut; seimbang dan mudah disukai.',
         'skor' => ['Aroma' => 4, 'Body' => 4, 'Keasaman' => 3, 'Manis' => 5], 'bintang' => 4.7,
         'cocok' => 'Espresso, moka pot, latte'],
        ['produk' => 'Kopi Robusta Lampung', 'asal' => 'Lampung', 'sangrai' => 'Medium - Dark',
         'catatan' => 'Pahit mantap, aroma cokelat dan rempah; kuat untuk penyuka kopi tebal.',
         'skor' => ['Aroma' => 3, 'Body' => 5, 'Keasaman' => 1, 'Manis' => 2], 'bintang' => 4.4,
         'cocok' => 'Kopi tubruk, kopi susu'],
        ['produk' => 'Es Kopi Susu Gula Aren', 'asal' => 'Racikan kedai', 'sangrai' => 'Medium',
         'catatan' => 'Susu segar dan gula aren membungkus espresso; creamy tapi rasa kopinya tetap terasa.',
         'skor' => ['Aroma' => 4, 'Body' => 4, 'Keasaman' => 2, 'Manis' => 5], 'bintang' => 4.9,
         'cocok' => 'Teman siang hari, dingin dari kulkas'],
        ['produk' => 'Kopi Hitam Dingin (Cold Brew)', 'asal' => 'Racikan kedai', 'sangrai' => 'Medium',
         'catatan' => 'Diseduh dingin 16 jam: halus, rendah pahit, manis alami tanpa gula.',
         'skor' => ['Aroma' => 4, 'Body' => 3, 'Keasaman' => 2, 'Manis' => 3], 'bintang' => 4.5,
         'cocok' => 'Diminum langsung atau dengan es batu'],
    ];
}

/** Contoh ulasan pelanggan (data demo). */
function daftarTestimoni(): array
{
    return [
        ['Aditya Nugroho', 'Web Developer', 5, 'Tempat andalan untuk bekerja dari kedai. Kopi Gayonya wangi dan suasananya tenang.'],
        ['Citra Lestari', 'Desainer Grafis', 5, 'Es Kopi Susu Gula Arennya pas: creamy, manisnya tidak berlebihan, rasa kopinya tetap terasa.'],
        ['Deni Wijaya', 'Fotografer', 5, 'Baristanya ramah dan enak diajak ngobrol soal asal biji kopi. Jadi tahu bedanya Gayo dan Kintamani.'],
        ['Hendra Kurnia', 'Penikmat Kopi', 4, 'Flores Bajawa diseduh V60 bersih sekali, ada manis karamelnya. Kemasan bijinya juga rapat dan wangi.'],
        ['Indah Permata', 'Arsitek', 5, 'Robusta Lampungnya mantap untuk tubruk pagi hari. Pesanan online sampai cepat dan rapi.'],
        ['Gita Amalia', 'Penulis', 4, 'Ruangannya nyaman untuk membaca. Cold brew-nya halus dan tidak pahit.'],
    ];
}

/** Path gambar produk; jatuh ke gambar default bila file tidak ada. */
function urlGambar(string $nama, string $base = ''): string
{
    $kandidat = ['assets/img/' . $nama, 'assets/img/uploads/' . $nama];
    foreach ($kandidat as $path) {
        if ($nama !== '' && is_file(__DIR__ . '/../' . $path)) {
            return $base . $path;
        }
    }
    return $base . 'assets/img/produk-default.svg';
}
