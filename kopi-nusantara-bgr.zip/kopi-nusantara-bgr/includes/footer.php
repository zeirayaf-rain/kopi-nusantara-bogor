<footer class="footer-kopi mt-5">
    <div class="container py-5">
        <div class="row g-4">
            <div class="col-md-5">
                <h5 class="fw-bold"><i class="bi bi-cup-hot-fill"></i> Kopi Nusantara Bogor</h5>
                <p>Menghadirkan kopi terbaik dari tanah air, langsung dari petani lokal ke cangkir Anda.</p>
                <h6 class="fw-bold mt-4">Ikuti Kami</h6>
                <?= ikonSosmed('terang') ?>
            </div>
            <div class="col-6 col-md-3">
                <h6 class="fw-bold">Menu</h6>
                <ul class="list-unstyled mb-0">
                    <li><a href="index.php">Beranda</a></li>
                    <li><a href="produk.php">Produk</a></li>
                    <li><a href="tentang.php">Tentang Kami</a></li>
                    <li><a href="kontak.php">Kontak</a></li>
                </ul>
            </div>
            <div class="col-6 col-md-4">
                <h6 class="fw-bold">Hubungi Kami</h6>
                <ul class="list-unstyled mb-0">
                    <li class="mb-1"><i class="bi bi-geo-alt"></i> Jl. Kopi No. 1, Bogor</li>
                    <li class="mb-1"><i class="bi bi-telephone"></i> 0812-0000-1234</li>
                    <li class="mb-1"><i class="bi bi-envelope"></i> halo@kopinusantarabogor.test</li>
                    <li><i class="bi bi-clock"></i> Senin - Sabtu, 08.00 - 20.00</li>
                </ul>
            </div>
        </div>
        <hr class="border-light opacity-25 my-4">
        <div class="d-flex flex-column flex-md-row justify-content-between small">
            <span>&copy; <?= date('Y') ?> Kopi Nusantara Bogor - Keenan Technology StartUp.</span>
        </div>
    </div>
</footer>

<!-- Lightbox galeri -->
<div class="modal fade" id="modalGaleri" tabindex="-1" aria-label="Foto galeri" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0">
            <button type="button" class="btn-close btn-close-white galeri-tutup" data-bs-dismiss="modal" aria-label="Tutup"></button>
            <div class="modal-body p-0">
                <img id="gambarGaleri" src="" alt="" class="img-fluid w-100">
            </div>
        </div>
    </div>
</div>

<!-- Popup info (perbedaan kopi & tips seduh) -->
<div class="modal fade" id="modalInfo" tabindex="-1" aria-labelledby="judulInfo" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0">
            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-center gap-3">
                    <div class="ikon-bulat"><i class="bi" id="ikonInfo"></i></div>
                    <h5 class="modal-title fw-bold" id="judulInfo"></h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body">
                <p class="text-muted" id="ringkasInfo"></p>
                <ul class="info-poin list-unstyled mb-0" id="poinInfo"></ul>
            </div>
        </div>
    </div>
</div>

<!-- Popup detail produk -->
<div class="modal fade" id="modalProduk" tabindex="-1" aria-labelledby="mpNama" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 overflow-hidden">
            <button type="button" class="btn-close position-absolute top-0 end-0 m-3 z-3" data-bs-dismiss="modal" aria-label="Tutup"></button>
            <div class="row g-0">
                <div class="col-md-5 bg-terakota d-flex align-items-center justify-content-center p-4">
                    <img id="mpGambar" src="" alt="" class="img-fluid" style="max-height:320px">
                </div>
                <div class="col-md-7 p-4 p-lg-5 d-flex flex-column">
                    <span class="badge badge-kategori align-self-start mb-2" id="mpKategori"></span>
                    <h2 class="h3 fw-bold" id="mpNama"></h2>
                    <p class="text-muted" id="mpDeskripsi"></p>
                    <div class="small mb-3" id="mpStok"></div>
                    <div class="mt-auto d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span class="h4 fw-bold harga mb-0" id="mpHarga"></span>
                        <a href="pesan.php" id="mpPesan" class="btn btn-kopi"><i class="bi bi-bag-heart"></i> Pesan Sekarang</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<a href="https://wa.me/<?= e(WA_NOMOR) ?>?text=<?= rawurlencode('Halo Kopi Nusantara Bogor, saya ingin bertanya tentang produk.') ?>"
   class="wa-float" target="_blank" rel="noopener noreferrer" aria-label="Chat WhatsApp Kopi NusantaraBogor" title="Chat WhatsApp">
    <i class="bi bi-whatsapp"></i>
</a>

<button id="btnAtas" class="btn btn-kopi rounded-circle" aria-label="Kembali ke atas">
    <i class="bi bi-arrow-up"></i>
</button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
