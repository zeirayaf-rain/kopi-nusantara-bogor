<?php
/**
 * Komponen kartu produk. Variabel $p = satu baris produk (array).
 * Jika $urut diisi (angka), kartu dipakai di grid halaman Produk dan muncul bertahap.
 * Jika $urut tidak diisi (slider beranda), kartu tampil seperti biasa tanpa jeda animasi.
 * Semua kartu bisa diklik untuk membuka popup detail produk.
 */
$urutKartu = $urut ?? null;
$gayaKartu = $urutKartu === null ? '' : ' style="transition-delay:' . (($urutKartu % 3) * 0.14) . 's"';
?>
<div class="card kartu-produk h-100 border-0 shadow-sm reveal"<?= $gayaKartu ?>
<?php if (true): ?>
     data-id="<?= (int) $p['id'] ?>" role="button" tabindex="0"
     aria-label="Lihat detail <?= e($p['nama']) ?>"
     data-nama="<?= e($p['nama']) ?>" data-kategori="<?= e($p['kategori']) ?>"
     data-deskripsi="<?= e($p['deskripsi']) ?>" data-harga="<?= e(rupiah((int) $p['harga'])) ?>"
     data-stok="<?= (int) $p['stok'] ?>" data-gambar="<?= e(urlGambar($p['gambar'])) ?>"
<?php endif; ?>>
    <div class="ratio ratio-1x1 bg-terakota">
        <img src="<?= e(urlGambar($p['gambar'])) ?>" class="card-img-top p-3"
             alt="<?= e($p['nama']) ?>" loading="lazy">
    </div>
    <div class="card-body d-flex flex-column">
        <span class="badge badge-kategori align-self-start mb-2"><?= e($p['kategori']) ?></span>
        <h3 class="h6 fw-bold"><?= e($p['nama']) ?></h3>
        <p class="small text-muted flex-grow-1"><?= e($p['deskripsi']) ?></p>
        <div class="d-flex justify-content-between align-items-center">
            <span class="fw-bold harga"><?= rupiah((int) $p['harga']) ?></span>
            <?php if ((int) $p['stok'] > 0): ?>
                <a href="pesan.php?produk=<?= (int) $p['id'] ?>" class="btn btn-kopi btn-sm">Pesan</a>
            <?php else: ?>
                <span class="badge text-bg-secondary">Stok habis</span>
            <?php endif; ?>
        </div>
    </div>
</div>
