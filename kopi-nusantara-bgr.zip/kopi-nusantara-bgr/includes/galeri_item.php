<?php
/**
 * Komponen satu foto galeri. Variabel $g = satu elemen dari daftarGaleri().
 * Klik membuka lightbox (lihat includes/footer.php dan assets/js/main.js).
 */
?>
<figure class="galeri-item reveal">
    <button type="button" class="galeri-tombol" data-bs-toggle="modal" data-bs-target="#modalGaleri"
            data-src="<?= e(urlGaleri($g['slug'])) ?>"
            data-judul="<?= e($g['judul']) ?>">
        <img src="<?= e(urlGaleri($g['slug'])) ?>" alt="<?= e($g['judul']) ?>" loading="lazy" onerror="this.onerror=null;this.src='assets/img/produk-default.svg'">
        <span class="galeri-zoom"><i class="bi bi-zoom-in"></i></span>
    </button>
</figure>
