<?php
/** Bagian "Asal Kopi" (dipakai di produk.php). */
?>
<section id="asal" class="mt-5 pt-4">
    <h2 class="fw-bold text-center mb-1">Asal Kopi Kami</h2>
    <p class="text-center text-muted mb-5">Ketinggian dan tanah tempat kopi tumbuh ikut menentukan rasa di cangkir Anda</p>

    <?php foreach (daftarAsal() as $i => $a): ?>
        <?php $idA = strtolower(str_replace(' ', '-', $a['nama'])); ?>
        <article id="asal-<?= e($idA) ?>" class="row align-items-center g-4 g-lg-5 mb-5 reveal">
            <div class="col-lg-6 <?= $i % 2 ? 'order-lg-2' : '' ?>">
                <figure class="m-0">
                    <img src="<?= e(urlFoto($a['foto'], 1000)) ?>" class="img-fluid rounded shadow-sm asal-foto"
                         alt="Foto ilustrasi kopi <?= e($a['nama']) ?>" loading="lazy"
                         onerror="this.onerror=null;this.src='assets/img/produk-default.svg'">
                    <figcaption class="small text-muted mt-1">Foto ilustrasi</figcaption>
                </figure>
            </div>
            <div class="col-lg-6">
                <span class="badge badge-kategori mb-2"><?= e($a['jenis']) ?></span>
                <h3 class="h2 fw-bold">Kopi <?= e($a['nama']) ?></h3>
                <p class="text-muted mb-3"><i class="bi bi-geo-alt-fill text-aksen"></i> <?= e($a['daerah']) ?></p>
                <dl class="row small mb-3">
                    <dt class="col-4">Ketinggian</dt><dd class="col-8"><?= e($a['tinggi']) ?></dd>
                    <dt class="col-4">Ciri rasa</dt><dd class="col-8"><?= e($a['ciri']) ?></dd>
                </dl>
                <p><?= e($a['fakta']) ?></p>
                <p class="small text-muted mb-0">Sumber:
                    <a href="<?= e($a['sumber'][1]) ?>" target="_blank" rel="noopener noreferrer"><?= e($a['sumber'][0]) ?></a></p>
            </div>
        </article>
    <?php endforeach; ?>

    <h3 class="h4 fw-bold text-center mt-5 mb-1">Arabika dan Robusta, apa bedanya?</h3>
    <p class="text-center text-muted mb-4">Dua jenis kopi utama yang kami jual</p>
    <div class="row g-4">
        <?php
        $beda = [
            ['Arabika', 'bi-flower2', 'Tumbuh di dataran tinggi. Rasanya lebih kompleks dengan keasaman dan aroma buah atau bunga. Cocok diseduh manual seperti V60.',
                'Ketinggian tanam' . '|Dataran tinggi, sekitar 800 - 2.000 mdpl.'
                . '~Rasa|Kompleks, keasaman lebih terasa, aroma bunga atau buah.'
                . '~Pahit dan kafein|Pahit lebih ringan, kafein lebih rendah (sekitar 1 - 1,5%).'
                . '~Cocok diseduh|V60, Japanese drip, espresso.'
                . '~Produk kami|Kopi Gayo Aceh, Flores Bajawa, dan Kintamani Bali (biji), serta bubuk Gayo dan Flores.'],
            ['Robusta', 'bi-lightning-charge', 'Rasa lebih pahit, pekat, dan kafeinnya lebih tinggi. Cocok untuk kopi tubruk dan kopi susu.',
                'Ketinggian tanam' . '|Dataran rendah hingga menengah.'
                . '~Rasa|Pahit mantap, pekat, body tebal, aroma cokelat dan rempah.'
                . '~Pahit dan kafein|Pahit lebih kuat, kafein lebih tinggi (sekitar 2 - 2,5%).'
                . '~Cocok diseduh|Kopi tubruk, moka pot, kopi susu.'
                . '~Produk kami|Kopi Robusta Lampung, Robusta Temanggung, dan Tubruk Nusantara Blend.'],
        ];
        foreach ($beda as [$namaB, $ikonB, $teksB, $poinB]): ?>
            <div class="col-md-6 reveal">
                <button type="button" class="kartu-info kartu-klik h-100 w-100 text-start"
                        data-bs-toggle="modal" data-bs-target="#modalInfo"
                        data-judul="<?= e($namaB) ?>" data-ikon="<?= e($ikonB) ?>"
                        data-ringkas="<?= e($teksB) ?>" data-poin="<?= e($poinB) ?>">
                    <div class="ikon-bulat mb-3"><i class="bi <?= $ikonB ?>"></i></div>
                    <h4 class="h5 fw-bold"><?= $namaB ?></h4>
                    <p class="mb-2 text-muted"><?= $teksB ?></p>
                    <span class="klik-info small"><i class="bi bi-hand-index-thumb"></i> Klik untuk detail</span>
                </button>
            </div>
        <?php endforeach; ?>
    </div>
</section>
