<?php
/**
 * Komponen kartu status pesanan.
 * Variabel: $r = satu baris pesanan (dengan kolom "produk"),
 *           $diperbarui = true bila status baru berubah sejak terakhir dilihat.
 */
$urutan = ['baru', 'diproses', 'dikirim', 'selesai'];
[$label, $warna] = infoStatus($r['status']);
[$labelBayar, $warnaBayar] = infoBayar($r['status_bayar'] ?? 'belum');
$batal = $r['status'] === 'batal';
$pos   = array_search($r['status'], $urutan, true);
?>
<article class="pesanan-kartu mb-3">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
        <div>
            <h3 class="h5 fw-bold mb-0">Pesanan #<?= (int) $r['id'] ?>
                <?php if (!empty($diperbarui)): ?>
                    <span class="badge text-bg-danger align-middle ms-1">Baru diperbarui</span>
                <?php endif; ?>
            </h3>
            <small class="text-muted"><?= e(date('d M Y, H:i', strtotime($r['created_at']))) ?></small>
        </div>
        <div class="text-end">
            <span class="badge text-bg-<?= e($warna) ?> fs-6"><?= e($label) ?></span>
            <div class="mt-1"><span class="badge text-bg-<?= e($warnaBayar) ?>"><i class="bi bi-wallet2"></i> <?= e($labelBayar) ?></span></div>
        </div>
    </div>
    <p class="mb-1"><?= e($r['produk']) ?> &times; <?= (int) $r['jumlah'] ?></p>
    <p class="fw-bold harga mb-2"><?= rupiah((int) $r['total']) ?></p>
    <?php if (!empty($r['kode_lacak'])): ?>
        <a href="struk.php?id=<?= (int) $r['id'] ?>&amp;kode=<?= e($r['kode_lacak']) ?>" target="_blank" rel="noopener"
           class="btn btn-outline-kopi btn-sm mb-3"><i class="bi bi-receipt"></i> Lihat Struk <?= e(noStruk($r)) ?></a>
    <?php endif; ?>

    <?php if (!$batal && ($r['status_bayar'] ?? 'belum') === 'belum'): ?>
        <div class="bayar-panel mb-3">
            <div class="fw-semibold mb-2"><i class="bi bi-wallet2"></i> Selesaikan pembayaran &middot; <?= e(labelMetode($r)) ?></div>
            <p class="small mb-2">Bayar tepat <strong><?= rupiah((int) $r['total']) ?></strong>, lalu unggah bukti pembayaran di bawah.</p>
            <?php if ($r['metode_bayar'] === 'qris'): ?>
                <div class="text-center mb-2">
                    <img src="<?= e(qrisUrl()) ?>" alt="Kode QRIS <?= e(QRIS_NAMA) ?>" class="qris-gambar">
                    <div class="small text-muted mt-1">QRIS a.n. <?= e(QRIS_NAMA) ?> &middot; bisa dipindai dari semua e-wallet &amp; m-banking</div>
                </div>
            <?php else: $rek = REKENING[$r['bank']] ?? null; ?>
                <?php if ($rek): ?>
                    <div class="rekening-kotak mb-2">
                        <div class="small text-muted">Transfer ke <?= e($r['bank']) ?></div>
                        <div class="d-flex align-items-center gap-2 flex-wrap">
                            <span class="h5 fw-bold mb-0"><?= e($rek['no']) ?></span>
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-salin="<?= e(preg_replace('/\D+/', '', $rek['no'])) ?>"><i class="bi bi-clipboard"></i> Salin</button>
                        </div>
                        <div class="small">a.n. <?= e($rek['atas_nama']) ?></div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <form method="post" action="pesan.php#status" enctype="multipart/form-data" class="row g-2 align-items-end">
                <?= csrfField() ?>
                <input type="hidden" name="aksi" value="bukti">
                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                <div class="col-sm-8">
                    <label for="bukti-<?= (int) $r['id'] ?>" class="form-label small mb-1">Foto bukti pembayaran (JPG/PNG/WEBP, maks. 3 MB)</label>
                    <input type="file" id="bukti-<?= (int) $r['id'] ?>" name="bukti" accept="image/jpeg,image/png,image/webp" class="form-control form-control-sm" required>
                </div>
                <div class="col-sm-4"><button type="submit" class="btn btn-kopi btn-sm w-100"><i class="bi bi-upload"></i> Kirim Bukti</button></div>
            </form>
        </div>
    <?php elseif (!$batal && ($r['status_bayar'] ?? '') === 'menunggu'): ?>
        <p class="small text-info-emphasis mb-3"><i class="bi bi-hourglass-split"></i> Bukti pembayaran sudah terkirim. Admin sedang memverifikasi, struk Anda akan berubah menjadi <strong>LUNAS</strong>.</p>
    <?php elseif (($r['status_bayar'] ?? '') === 'lunas'): ?>
        <p class="small text-success mb-3"><i class="bi bi-patch-check-fill"></i> Pembayaran lunas<?= !empty($r['dibayar_at']) ? ' pada ' . e(date('d M Y, H:i', strtotime($r['dibayar_at']))) : '' ?>. Terima kasih!</p>
    <?php endif; ?>

    <?php if ($batal): ?>
        <p class="text-danger small mb-0"><i class="bi bi-x-circle"></i> Pesanan ini dibatalkan.</p>
    <?php else: ?>
        <ol class="langkah" aria-label="Progres pesanan">
            <?php foreach ($urutan as $i => $s): ?>
                <li class="<?= $i <= $pos ? 'selesai' : '' ?><?= $i === $pos ? ' sekarang' : '' ?>">
                    <span class="titik"></span><?= e(infoStatus($s)[0]) ?>
                </li>
            <?php endforeach; ?>
        </ol>
    <?php endif; ?>
</article>
