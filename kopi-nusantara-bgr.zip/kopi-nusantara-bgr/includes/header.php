<?php
/**
 * Header + navbar halaman publik.
 * Variabel yang diharapkan dari halaman pemanggil:
 *   $judul  (string) judul halaman
 *   $aktif  (string) menu aktif: beranda | produk | tentang | kontak | pesan
 */
require_once __DIR__ . '/functions.php';

$judul = $judul ?? 'Kopi Nusantara Bogor';
$aktif = $aktif ?? '';

// Notifikasi perubahan status pesanan (tanpa akun, lewat cookie peramban)
$notif       = notifPesanan();
$jumlahNotif = count($notif);

$menu = [
    'beranda' => ['index.php',   'Beranda'],
    'produk'  => ['produk.php',  'Produk'],
    'tentang' => ['tentang.php', 'Tentang Kami'],
    'kontak'  => ['kontak.php',  'Kontak'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Kopi Nusantara Bogor - kopi kemasan dan minuman kopi siap saji dari petani lokal Indonesia.">
    <title><?= e($judul) ?> | Kopi Nusantara Bogor</title>

    <!-- Library: Bootstrap 5 + Animate.css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/animate.css@4.1.1/animate.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Fraunces:ital,opsz,wght@0,9..144,600;1,9..144,500&display=swap" rel="stylesheet">
    <!-- CSS milik proyek -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<!-- Banner promo berjalan -->
<div class="promo-bar" role="region" aria-label="Promo kopi">
    <div class="promo-track">
        <?php for ($ulang = 0; $ulang < 2; $ulang++): ?>
            <div class="promo-grup"<?= $ulang ? ' aria-hidden="true"' : '' ?>>
                <?php foreach (PROMO as $kodePromo => $pr): ?>
                    <a class="promo-item" href="pesan.php?promo=<?= e($kodePromo) ?>"<?= $ulang ? ' tabindex="-1"' : '' ?>>
                        <i class="bi bi-cup-hot-fill"></i> <?= e($pr['judul']) ?> - kode <strong><?= e($kodePromo) ?></strong>
                        (min. <?= e(rupiah($pr['min'])) ?>) <span class="promo-klaim">Klaim</span>
                    </a>
                <?php endforeach; ?>
                <span class="promo-item"><i class="bi bi-bag-heart"></i> Pesan online tanpa daftar, cek status kapan saja</span>
            </div>
        <?php endfor; ?>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-kopi sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">
            <i class="bi bi-cup-hot-fill"></i> Kopi Nusantara Bogor
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#menuUtama" aria-controls="menuUtama"
                aria-expanded="false" aria-label="Buka menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuUtama">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <?php foreach ($menu as $kunci => [$url, $label]): ?>
                    <li class="nav-item">
                        <a class="nav-link<?= $aktif === $kunci ? ' active' : '' ?>"
                           href="<?= $url ?>"><?= $label ?></a>
                    </li>
                <?php endforeach; ?>
                <li class="nav-item">
                    <a class="nav-link" href="admin/<?= !empty($_SESSION['admin_id']) ? 'index.php' : 'login.php' ?>">
                        <i class="bi bi-person-lock"></i> <?= !empty($_SESSION['admin_id']) ? 'Dashboard Admin' : 'Login Admin' ?>
                    </a>
                </li>
                <li class="nav-item ms-lg-2">
                    <a class="btn btn-kopi btn-sm px-3" href="pesan.php">
                        <i class="bi bi-bag-heart"></i> Pesan Sekarang / Cek Pesanan
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<?php if ($jumlahNotif > 0): ?>
    <div class="notif-toast" role="status">
        <i class="bi bi-bell-fill"></i>
        <div>
            <strong>Pesanan #<?= (int) $notif[0]['id'] ?></strong> <?= e(pesanStatus($notif[0]['status'])) ?><?= $jumlahNotif > 1 ? ' (+' . ($jumlahNotif - 1) . ' lainnya)' : '' ?><br>
            <a href="pesan.php#status">Lihat status</a>
        </div>
        <button type="button" class="btn-close btn-close-white" aria-label="Tutup" onclick="this.parentNode.remove()"></button>
    </div>
<?php endif; ?>
