<?php
/** Bagian "Catatan Rasa" + tips seduh (dipakai di produk.php). */
$petaId = [];
foreach (ambilProduk() as $row) {
    $petaId[$row['nama']] = (int) $row['id'];
}
?>
<section id="ulasan" class="mt-5 pt-4">
    <h2 class="fw-bold text-center mb-1">Ulasan Kopi</h2>
    <p class="text-center text-muted mb-4">Catatan rasa dari tim Kopi NusantaraBogor</p>
<div class="row g-4">
        <?php foreach (daftarUlasan() as $u): ?>
            <div class="col-lg-6 reveal">
                <article class="ulasan-kartu h-100">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <h3 class="h5 fw-bold mb-0"><?= e($u['produk']) ?></h3>
                            <small class="text-muted"><?= e($u['asal']) ?> &middot; Sangrai <?= e($u['sangrai']) ?></small>
                        </div>
                        <span class="nilai"><i class="bi bi-star-fill"></i> <?= number_format($u['bintang'], 1, ',', '') ?></span>
                    </div>
                    <p class="mb-3"><?= e($u['catatan']) ?></p>
                    <?php foreach ($u['skor'] as $aspek => $nilai): ?>
                        <div class="meter" role="img" aria-label="<?= e($aspek) ?> <?= (int) $nilai ?> dari 5">
                            <span class="meter-label"><?= e($aspek) ?></span>
                            <span class="meter-bar"><span style="width: <?= (int) $nilai * 20 ?>%"></span></span>
                        </div>
                    <?php endforeach; ?>
                    <p class="small text-muted mt-3 mb-3"><strong>Cocok untuk:</strong> <?= e($u['cocok']) ?></p>
                    <?php if (isset($petaId[$u['produk']])): ?>
                        <a href="pesan.php?produk=<?= $petaId[$u['produk']] ?>" class="btn btn-kopi btn-sm">Pesan</a>
                    <?php endif; ?>
                </article>
            </div>
        <?php endforeach; ?>
    </div>

    <h3 class="h4 fw-bold text-center mt-5 mb-1">Tips Seduh di Rumah</h3>
    <p class="text-center text-muted mb-4">Panduan umum; sesuaikan dengan selera Anda</p>
    <div class="row g-4">
        <?php
        $tips = [
            ['bi-droplet-half', 'V60 (arabika)', 'Gunakan air sekitar 92&deg;C dengan rasio kopi dan air 1:15 sampai 1:16. Tuang perlahan dalam beberapa tahap.',
                'Bilas filter|Basahi filter kertas dengan air panas, lalu buang airnya.'
                . '~Takaran|15 g kopi gilas sedang dengan 240 ml air (rasio sekitar 1:16).'
                . '~Bloom|Tuang sekitar 30 ml air, tunggu 30 detik agar kopi mengembang.'
                . '~Tuang bertahap|Tuang melingkar perlahan sampai takaran habis, total waktu sekitar 2,5 - 3 menit.'],
            ['bi-cup-hot', 'Tubruk (robusta)', 'Seduh bubuk dengan air panas, diamkan beberapa menit sampai ampas turun, lalu minum perlahan.',
                'Takaran|2 sendok makan bubuk kopi halus dalam gelas.'
                . '~Seduh|Tuang sekitar 150 ml air 90 - 95 derajat C, aduk rata.'
                . '~Diamkan|Tunggu 3 - 4 menit sampai ampas mengendap.'
                . '~Minum|Minum perlahan dan sisakan ampas di dasar gelas.'],
            ['bi-snow2', 'Cold brew', 'Rendam kopi gilas kasar dalam air dingin di kulkas selama 12 sampai 16 jam, lalu saring.',
                'Takaran|Kopi gilas kasar dan air dengan rasio sekitar 1:8 (contoh 100 g kopi dengan 800 ml air).'
                . '~Rendam|Campur dalam wadah tertutup, simpan di kulkas 12 - 16 jam.'
                . '~Saring|Saring dengan kertas filter atau kain bersih sampai jernih.'
                . '~Sajikan|Minum dengan es batu. Simpan di kulkas dan habiskan dalam beberapa hari.'],
        ];
        foreach ($tips as [$ikon, $judulT, $teksT, $poinT]): ?>
            <div class="col-md-4 reveal">
                <button type="button" class="kartu-info kartu-klik h-100 w-100 text-start"
                        data-bs-toggle="modal" data-bs-target="#modalInfo"
                        data-judul="<?= e(html_entity_decode($judulT)) ?>" data-ikon="<?= e($ikon) ?>"
                        data-ringkas="<?= e(html_entity_decode($teksT)) ?>" data-poin="<?= e($poinT) ?>" data-urut="1">
                    <div class="ikon-bulat mb-3"><i class="bi <?= $ikon ?>"></i></div>
                    <h4 class="h6 fw-bold"><?= $judulT ?></h4>
                    <p class="small text-muted mb-2"><?= $teksT ?></p>
                    <span class="klik-info small"><i class="bi bi-hand-index-thumb"></i> Klik untuk langkah lengkap</span>
                </button>
            </div>
        <?php endforeach; ?>
    </div>
</section>
