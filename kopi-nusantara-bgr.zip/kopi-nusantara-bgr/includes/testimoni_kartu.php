<?php
/** Kartu testimoni. Variabel: $nama, $profesi, $bintang (1-5), $isi. */
?>
<figure class="testi-kartu h-100">
    <div class="bintang mb-2" role="img" aria-label="Nilai <?= (int) $bintang ?> dari 5">
        <?php for ($i = 1; $i <= 5; $i++): ?>
            <i class="bi bi-star<?= $i <= $bintang ? '-fill' : '' ?>"></i>
        <?php endfor; ?>
    </div>
    <blockquote class="mb-3">&ldquo;<?= e($isi) ?>&rdquo;</blockquote>
    <figcaption><strong><?= e($nama) ?></strong><br><small class="text-muted"><?= e($profesi) ?></small></figcaption>
</figure>
