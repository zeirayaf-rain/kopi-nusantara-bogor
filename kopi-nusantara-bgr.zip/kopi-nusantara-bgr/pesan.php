<?php
/**
 * Halaman Pemesanan Online (tanpa akun/login).
 * - Form pemesanan dengan validasi dan kalkulasi total otomatis.
 * - Bagian "Status Pesanan" di halaman yang sama: pesanan dari peramban ini
 *   tampil otomatis (cookie), atau cek dengan nomor pesanan + nomor telepon.
 */
$judul = 'Pesan Online';
$aktif = 'pesan';

require_once __DIR__ . '/includes/functions.php';

$produkList = ambilProduk();

/** Susun daftar produk menjadi array [id => baris produk]. */
function petakanProduk(array $produkList): array
{
    $peta = [];
    foreach ($produkList as $p) {
        $peta[(int) $p['id']] = $p;
    }
    return $peta;
}

/**
 * Validasi data pesanan. Mengembalikan array pesan galat per kolom
 * (kosong berarti valid).
 */
function validasiPesanan(array $in, array $peta): array
{
    $galat = [];

    if (mb_strlen($in['nama']) < 3) {
        $galat['nama'] = 'Nama minimal 3 karakter.';
    }
    if (mb_strlen($in['alamat']) < 10) {
        $galat['alamat'] = 'Alamat minimal 10 karakter.';
    }
    if (!preg_match('/^[0-9+\-\s]{8,20}$/', $in['telepon'])) {
        $galat['telepon'] = 'Nomor telepon tidak valid (8-20 digit).';
    }

    if (!isset(METODE_BAYAR[$in['metode']])) {
        $galat['metode'] = 'Pilih metode pembayaran.';
    } elseif ($in['metode'] === 'transfer' && !isset(REKENING[$in['bank']])) {
        $galat['bank'] = 'Pilih bank tujuan transfer.';
    }

    if (!isset($peta[$in['produk_id']])) {
        $galat['produk_id'] = 'Silakan pilih produk.';
    } else {
        $stok = (int) $peta[$in['produk_id']]['stok'];
        if ($in['jumlah'] < 1) {
            $galat['jumlah'] = 'Jumlah minimal 1.';
        } elseif ($in['jumlah'] > $stok) {
            $galat['jumlah'] = "Stok tersedia hanya {$stok}.";
        } else {
            // Kode promo (opsional)
            $sub = (int) $peta[$in['produk_id']]['harga'] * $in['jumlah'];
            [, $galatPromo] = hitungPromo($in['promo'], $peta[$in['produk_id']], $sub);
            if ($galatPromo) {
                $galat['promo'] = $galatPromo;
            }
        }
    }

    return $galat;
}

/** Hitung total harga = harga satuan x jumlah. */
function hitungTotal(int $harga, int $jumlah): int
{
    return $harga * $jumlah;
}

$peta  = petakanProduk($produkList);
$galat = [];
$galatCek = '';
$input = [
    'nama'      => '',
    'alamat'    => '',
    'telepon'   => '',
    'produk_id' => filter_input(INPUT_GET, 'produk', FILTER_VALIDATE_INT) ?: 0,
    'jumlah'    => 1,
    'promo'     => isset(PROMO[strtoupper(trim($_GET['promo'] ?? ''))]) ? strtoupper(trim($_GET['promo'])) : '',
    'metode'    => 'qris',
    'bank'      => (string) array_key_first(REKENING),
];
$galatBukti = '';
$cekNomor = '';
$cekTelp  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $aksi = $_POST['aksi'] ?? 'pesan';

    if ($aksi === 'cek') {
        // ---- Cek status dari perangkat lain: nomor pesanan + nomor telepon ----
        $cekNomor = trim($_POST['nomor'] ?? '');
        $cekTelp  = trim($_POST['telepon_cek'] ?? '');

        if (($_SESSION['cek_blokir'] ?? 0) > time()) {
            $galatCek = 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.';
        } else {
            $nomor = (int) ltrim($cekNomor, '#');
            $r = $nomor > 0 ? cariPesanan($nomor, $cekTelp) : null;
            if ($r) {
                unset($_SESSION['cek_gagal'], $_SESSION['cek_blokir']);
                ingatPesanan((int) $r['id'], $r['kode_lacak']); // tampil otomatis di perangkat ini
                $_SESSION['info_status'] = 'Pesanan #' . (int) $r['id'] . ' ditemukan dan ditampilkan di bawah.';
                redirect('pesan.php#status');
            }
            $_SESSION['cek_gagal'] = ($_SESSION['cek_gagal'] ?? 0) + 1;
            if ($_SESSION['cek_gagal'] >= 5) {
                $_SESSION['cek_gagal'] = 0;
                $_SESSION['cek_blokir'] = time() + 300;
            }
            $galatCek = 'Pesanan tidak ditemukan. Pastikan nomor pesanan dan nomor telepon sama dengan saat memesan.';
        }
    } elseif ($aksi === 'bukti') {
        // ---- Unggah bukti pembayaran (hanya untuk pesanan milik peramban ini) ----
        $idBayar = (int) ($_POST['id'] ?? 0);
        $milik   = null;
        foreach (pesananPeramban() as $kandidat) {
            if ((int) $kandidat['id'] === $idBayar) {
                $milik = $kandidat;
                break;
            }
        }
        if (!$milik || $milik['status_bayar'] === 'lunas' || $milik['status'] === 'batal') {
            $galatBukti = 'Pesanan tidak ditemukan atau tidak dapat dibayar lagi.';
        } else {
            try {
                $nama = simpanBukti($_FILES['bukti'] ?? [], $idBayar);
                hapusBukti((string) $milik['bukti_bayar']); // ganti bukti lama bila ada
                db()->prepare("UPDATE pesanan SET bukti_bayar = ?, status_bayar = 'menunggu' WHERE id = ?")
                    ->execute([$nama, $idBayar]);
                $_SESSION['info_status'] = 'Bukti pembayaran pesanan #' . $idBayar . ' terkirim. Admin akan memverifikasi sebentar lagi.';
                redirect('pesan.php#status');
            } catch (RuntimeException $ex) {
                $galatBukti = $ex->getMessage();
            }
        }
    } else {
        // ---- Buat pesanan baru ----
        $input = [
            'nama'      => trim($_POST['nama'] ?? ''),
            'alamat'    => trim($_POST['alamat'] ?? ''),
            'telepon'   => trim($_POST['telepon'] ?? ''),
            'produk_id' => (int) ($_POST['produk_id'] ?? 0),
            'jumlah'    => (int) ($_POST['jumlah'] ?? 0),
            'promo'     => strtoupper(trim($_POST['promo'] ?? '')),
            'metode'    => (string) ($_POST['metode'] ?? ''),
            'bank'      => (string) ($_POST['bank'] ?? ''),
        ];
        $galat = validasiPesanan($input, $peta);

        if (!$galat) {
            $pdo = db();
            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare('INSERT INTO pelanggan (nama, alamat, telepon) VALUES (?, ?, ?)');
                $stmt->execute([$input['nama'], $input['alamat'], $input['telepon']]);
                $pelangganId = (int) $pdo->lastInsertId();

                // Kurangi stok hanya jika masih mencukupi (mencegah stok minus)
                $stmt = $pdo->prepare('UPDATE produk SET stok = stok - ? WHERE id = ? AND stok >= ?');
                $stmt->execute([$input['jumlah'], $input['produk_id'], $input['jumlah']]);
                if ($stmt->rowCount() === 0) {
                    throw new RuntimeException('Stok tidak mencukupi.');
                }

                $subtotal = hitungTotal((int) $peta[$input['produk_id']]['harga'], $input['jumlah']);
                [$diskon] = hitungPromo($input['promo'], $peta[$input['produk_id']], $subtotal);
                $total = $subtotal - $diskon;
                $kode  = kodeLacakBaru();
                $bank  = $input['metode'] === 'transfer' ? $input['bank'] : '';
                $stmt  = $pdo->prepare('INSERT INTO pesanan (pelanggan_id, produk_id, jumlah, total, kode_lacak, metode_bayar, bank) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$pelangganId, $input['produk_id'], $input['jumlah'], $total, $kode, $input['metode'], $bank]);
                $nomor = (int) $pdo->lastInsertId();

                $pdo->commit();

                // Ingat di peramban ini, lalu muat ulang agar refresh tidak mengirim pesanan dobel
                ingatPesanan($nomor, $kode);
                $_SESSION['pesanan_berhasil'] = ['nomor' => $nomor, 'total' => $total, 'diskon' => $diskon, 'promo' => $input['promo'], 'nama' => $input['nama'], 'metode' => $input['metode'], 'bank' => $bank];
                redirect('pesan.php#status');
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $galat['umum'] = $ex instanceof RuntimeException
                    ? $ex->getMessage()
                    : 'Terjadi kesalahan saat menyimpan pesanan. Coba lagi.';
            }
        }
    }
}

// Pesan sekali tampil dari pengalihan sebelumnya
$berhasil = $_SESSION['pesanan_berhasil'] ?? null;
$infoStatus = $_SESSION['info_status'] ?? null;
unset($_SESSION['pesanan_berhasil'], $_SESSION['info_status']);

// Pesanan milik peramban ini
$daftarSaya = pesananPeramban();

// Isi otomatis data pemesan dari pesanan terakhir (bila form belum diisi)
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $daftarSaya) {
    $input['nama']    = $daftarSaya[0]['nama_pemesan'];
    $input['telepon'] = $daftarSaya[0]['telepon'];
    $input['alamat']  = $daftarSaya[0]['alamat'];
}

// Catat pesanan yang statusnya baru berubah, lalu tandai sudah dilihat
// (sebelum header agar notifikasi di pojok tidak muncul lagi di halaman ini)
$berubah = [];
foreach ($daftarSaya as $r) {
    if ($r['status'] !== $r['status_dilihat']) {
        $berubah[(int) $r['id']] = true;
    }
}
tandaiDilihat(array_keys($berubah));

require __DIR__ . '/includes/header.php';
?>

<header class="page-header text-center" style="<?= e(bannerStyle('kopi-5.jpg')) ?>">
    <div class="container">
        <h1 class="fw-bold animate__animated animate__fadeInDown">Pesan Online</h1>
        <p class="mb-0">Isi formulir berikut, tanpa perlu daftar atau masuk akun</p>
    </div>
</header>

<main class="container py-5">
    <div class="row g-4 justify-content-center">
        <div class="col-lg-8">

                <?php if (isset($galat['umum'])): ?>
                    <div class="alert alert-danger"><?= e($galat['umum']) ?></div>
                <?php endif; ?>

                <form id="formPesan" method="post" action="pesan.php" novalidate class="card border-0 shadow-sm p-4"
                      data-promo="<?= e(json_encode(PROMO)) ?>">
                    <?= csrfField() ?>
                    <input type="hidden" name="aksi" value="pesan">

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama lengkap</label>
                        <input type="text" id="nama" name="nama" value="<?= e($input['nama']) ?>"
                               class="form-control<?= isset($galat['nama']) ? ' is-invalid' : '' ?>">
                        <div class="invalid-feedback"><?= e($galat['nama'] ?? 'Nama minimal 3 karakter.') ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="telepon" class="form-label">Nomor telepon / WhatsApp</label>
                        <input type="tel" id="telepon" name="telepon" value="<?= e($input['telepon']) ?>"
                               class="form-control<?= isset($galat['telepon']) ? ' is-invalid' : '' ?>">
                        <div class="invalid-feedback"><?= e($galat['telepon'] ?? 'Nomor telepon tidak valid.') ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat pengiriman</label>
                        <textarea id="alamat" name="alamat" rows="3"
                                  class="form-control<?= isset($galat['alamat']) ? ' is-invalid' : '' ?>"><?= e($input['alamat']) ?></textarea>
                        <div class="invalid-feedback"><?= e($galat['alamat'] ?? 'Alamat minimal 10 karakter.') ?></div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-8">
                            <label for="produk_id" class="form-label">Pilihan produk</label>
                            <select id="produk_id" name="produk_id"
                                    class="form-select<?= isset($galat['produk_id']) ? ' is-invalid' : '' ?>">
                                <option value="">-- Pilih produk --</option>
                                <?php foreach ($produkList as $p): ?>
                                    <option value="<?= (int) $p['id'] ?>"
                                            data-harga="<?= (int) $p['harga'] ?>"
                                            data-stok="<?= (int) $p['stok'] ?>"
                                            data-kategori="<?= e($p['kategori']) ?>"
                                            <?= $input['produk_id'] === (int) $p['id'] ? 'selected' : '' ?>
                                            <?= (int) $p['stok'] === 0 ? 'disabled' : '' ?>>
                                        <?= e($p['nama']) ?> - <?= rupiah((int) $p['harga']) ?>
                                        <?= (int) $p['stok'] === 0 ? '(habis)' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback"><?= e($galat['produk_id'] ?? 'Silakan pilih produk.') ?></div>
                        </div>
                        <div class="col-md-4">
                            <label for="jumlah" class="form-label">Jumlah</label>
                            <input type="number" id="jumlah" name="jumlah" min="1" value="<?= (int) $input['jumlah'] ?>"
                                   class="form-control<?= isset($galat['jumlah']) ? ' is-invalid' : '' ?>">
                            <div class="invalid-feedback"><?= e($galat['jumlah'] ?? 'Jumlah minimal 1.') ?></div>
                        </div>
                    </div>

                    <div class="mt-3">
                        <label for="promo" class="form-label">Kode promo <span class="text-muted small">(opsional)</span></label>
                        <input type="text" id="promo" name="promo" value="<?= e($input['promo']) ?>" maxlength="20"
                               placeholder="contoh: KOPI10" autocomplete="off"
                               class="form-control text-uppercase<?= isset($galat['promo']) ? ' is-invalid' : '' ?>">
                        <div class="invalid-feedback"><?= e($galat['promo'] ?? '') ?></div>
                        <div id="infoPromo" class="small mt-1" aria-live="polite"></div>
                    </div>

                    <fieldset class="mt-4">
                        <legend class="form-label fs-6">Metode pembayaran</legend>
                        <div class="row g-2">
                            <?php foreach (METODE_BAYAR as $kodeM => $namaM): ?>
                                <div class="col-sm-6">
                                    <input type="radio" class="btn-check" name="metode" id="metode-<?= e($kodeM) ?>"
                                           value="<?= e($kodeM) ?>" <?= $input['metode'] === $kodeM ? 'checked' : '' ?>>
                                    <label class="btn btn-outline-kopi w-100 text-start py-2" for="metode-<?= e($kodeM) ?>">
                                        <i class="bi <?= $kodeM === 'qris' ? 'bi-qr-code-scan' : 'bi-bank' ?>"></i>
                                        <strong><?= e($namaM) ?></strong>
                                        <span class="d-block small opacity-75"><?= $kodeM === 'qris' ? 'Scan dengan e-wallet / m-banking' : 'Transfer ke rekening kedai' ?></span>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php if (isset($galat['metode'])): ?><div class="text-danger small mt-1"><?= e($galat['metode']) ?></div><?php endif; ?>

                        <div id="pilihBank" class="mt-3<?= $input['metode'] === 'transfer' ? '' : ' d-none' ?>">
                            <label for="bank" class="form-label">Bank tujuan transfer</label>
                            <select id="bank" name="bank" class="form-select<?= isset($galat['bank']) ? ' is-invalid' : '' ?>">
                                <?php foreach (REKENING as $namaBank => $rek): ?>
                                    <option value="<?= e($namaBank) ?>" <?= $input['bank'] === $namaBank ? 'selected' : '' ?>><?= e($namaBank) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback"><?= e($galat['bank'] ?? '') ?></div>
                        </div>
                        <p class="small text-muted mt-2 mb-0">Instruksi pembayaran dan struk langsung muncul di bawah setelah pesanan dikirim.</p>
                    </fieldset>

                    <div class="total-box mt-4">
                        <div class="d-flex justify-content-between small"><span>Subtotal</span><span id="subtotalHarga">Rp 0</span></div>
                        <div id="barisDiskon" class="d-flex justify-content-between small text-success d-none">
                            <span>Diskon promo</span><span id="diskonHarga">- Rp 0</span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border-top mt-2 pt-2">
                            <span class="fw-semibold">Total harga</span>
                            <span id="totalHarga" class="h4 fw-bold mb-0">Rp 0</span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-kopi btn-lg mt-4">
                        <i class="bi bi-bag-check"></i> Kirim Pesanan
                    </button>
                </form>

            <!-- ========== Status pesanan (tanpa login) ========== -->
            <section id="status" class="mt-5 pt-2">
                <h2 class="h4 fw-bold mb-3"><i class="bi bi-receipt"></i> Riwayat Pemesanan &amp; Struk</h2>

                <?php if ($berhasil): ?>
                    <div class="alert alert-success animate__animated animate__fadeIn">
                        <h3 class="h5 fw-bold">Pesanan berhasil dibuat!</h3>
                        <p class="mb-1">Terima kasih, <strong><?= e($berhasil['nama']) ?></strong>.</p>
                        <p class="mb-1">Nomor pesanan: <strong>#<?= (int) $berhasil['nomor'] ?></strong></p>
                        <?php if (!empty($berhasil['diskon'])): ?>
                            <p class="mb-1">Promo <strong><?= e($berhasil['promo']) ?></strong>: hemat <strong><?= rupiah((int) $berhasil['diskon']) ?></strong></p>
                        <?php endif; ?>
                        <p class="mb-1">Total pembayaran: <strong><?= rupiah($berhasil['total']) ?></strong></p>
                        <p class="mb-2">Metode: <strong><?= e(METODE_BAYAR[$berhasil['metode']] ?? '') ?><?= $berhasil['bank'] !== '' ? ' ' . e($berhasil['bank']) : '' ?></strong></p>
                        <p class="mb-0 small">Struk pesanan Anda sudah masuk ke riwayat di bawah ini. Lakukan pembayaran lalu unggah bukti agar admin dapat memverifikasi. Catat nomor pesanan untuk cek dari HP atau perangkat lain.</p>
                    </div>
                <?php elseif ($infoStatus): ?>
                    <div class="alert alert-info"><?= e($infoStatus) ?></div>
                <?php endif; ?>

                <?php if ($galatBukti): ?>
                    <div class="alert alert-danger"><?= e($galatBukti) ?></div>
                <?php endif; ?>

                <?php if ($daftarSaya): ?>
                    <?php foreach ($daftarSaya as $r): ?>
                        <?php $diperbarui = isset($berubah[(int) $r['id']]); ?>
                        <?php include __DIR__ . '/includes/kartu_pesanan.php'; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted">Belum ada pesanan dari perangkat ini. Setelah memesan, struk dan statusnya akan tampil di sini.</p>
                <?php endif; ?>

                <div class="card border-0 shadow-sm p-4 mt-4">
                    <h3 class="h6 fw-bold">Pesan dari HP atau perangkat lain?</h3>
                    <p class="small text-muted">Masukkan nomor pesanan dan nomor telepon yang dipakai saat memesan.</p>
                    <?php if ($galatCek): ?>
                        <div class="alert alert-danger py-2 small"><?= e($galatCek) ?></div>
                    <?php endif; ?>
                    <form method="post" action="pesan.php#status" novalidate class="row g-2">
                        <?= csrfField() ?>
                        <input type="hidden" name="aksi" value="cek">
                        <div class="col-sm-4">
                            <label for="nomor" class="form-label small mb-1">Nomor pesanan</label>
                            <input type="text" id="nomor" name="nomor" value="<?= e($cekNomor) ?>" inputmode="numeric"
                                   placeholder="contoh: 12" class="form-control" required>
                        </div>
                        <div class="col-sm-5">
                            <label for="telepon_cek" class="form-label small mb-1">Nomor telepon</label>
                            <input type="tel" id="telepon_cek" name="telepon_cek" value="<?= e($cekTelp) ?>"
                                   placeholder="contoh: 081234567890" class="form-control" required>
                        </div>
                        <div class="col-sm-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-outline-kopi w-100">Cek Status</button>
                        </div>
                    </form>
                </div>
            </section>

        </div>

        <!-- ========== Samping: klaim promo ========== -->
        <aside class="col-lg-4">
            <div class="promo-samping">
                <div class="card border-0 shadow-sm p-4">
                    <h2 class="h5 fw-bold mb-1"><i class="bi bi-ticket-perforated text-aksen"></i> Klaim Promo</h2>
                    <p class="small text-muted">Klik Klaim, kodenya langsung terpasang di formulir pesanan.</p>
                    <div class="d-grid gap-3">
                        <?php foreach (PROMO as $kodePromo => $pr): ?>
                            <div class="promo-kartu">
                                <span class="promo-kode"><?= e($kodePromo) ?></span>
                                <div class="fw-semibold mt-2"><?= e($pr['judul']) ?></div>
                                <div class="small text-muted mb-2">Min. belanja <?= e(rupiah($pr['min'])) ?></div>
                                <button type="button" class="btn btn-kopi btn-sm" data-klaim="<?= e($kodePromo) ?>">Klaim</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </aside>
    </div>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
