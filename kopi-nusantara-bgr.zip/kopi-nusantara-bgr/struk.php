<?php
/**
 * Struk pembayaran / bukti pesanan (siap cetak atau simpan sebagai PDF).
 * Akses: ?id=NOMOR&kode=KODE_LACAK (dari halaman Pesan), atau admin yang sudah login.
 */
require_once __DIR__ . '/includes/functions.php';

$id   = (int) ($_GET['id'] ?? 0);
$kode = (string) ($_GET['kode'] ?? '');
$admin = !empty($_SESSION['admin_id']);

$stmt = db()->prepare(
    'SELECT ps.*, pr.nama AS produk, pr.harga, k.nama AS kategori,
            pl.nama AS pemesan, pl.alamat, pl.telepon
     FROM pesanan ps
     JOIN produk pr ON pr.id = ps.produk_id
     JOIN kategori k ON k.id = pr.kategori_id
     JOIN pelanggan pl ON pl.id = ps.pelanggan_id
     WHERE ps.id = ?'
);
$stmt->execute([$id]);
$r = $stmt->fetch();

$boleh = $r && ($admin || ($r['kode_lacak'] !== '' && hash_equals((string) $r['kode_lacak'], $kode)));
if (!$boleh) {
    http_response_code(404);
    exit('Struk tidak ditemukan atau tautannya tidak valid.');
}

// Subtotal memakai harga produk saat ini; selisih dengan total tersimpan = diskon promo
$subtotal = (int) $r['harga'] * (int) $r['jumlah'];
$diskon   = max(0, $subtotal - (int) $r['total']);
[$labelStatus] = infoStatus($r['status']);
[$labelBayar, $warnaBayar] = infoBayar($r['status_bayar']);
$lunas = $r['status_bayar'] === 'lunas';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Struk Pembayaran #<?= (int) $r['id'] ?> | Kopi NusantaraBogor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f4f1ed; }
        .struk { max-width: 460px; background: #fff; border-radius: .75rem; box-shadow: 0 .5rem 1.5rem rgba(59,35,20,.12); }
        .struk .garis { border-top: 2px dashed #b9a893; }
        .cap { display: inline-block; padding: .15rem .9rem; border: 3px solid; border-radius: .4rem;
               font-weight: 800; letter-spacing: .15em; transform: rotate(-6deg); }
        .cap-lunas { color: #198754; }
        .cap-belum { color: #b58100; }
        .cap-menunggu { color: #0a7a99; }
        @media print {
            body { background: #fff; }
            .struk { box-shadow: none; max-width: 100%; }
            .tanpa-cetak { display: none !important; }
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="struk mx-auto p-4">
        <div class="text-center mb-3">
            <div class="fs-3"><i class="bi bi-cup-hot-fill"></i></div>
            <h1 class="h5 fw-bold mb-0">Kopi NusantaraBogor</h1>
            <div class="small text-muted">Jl. Kopi No. 1, Bogor, Jawa Barat &middot; 0812-0000-1234</div>
            <div class="fw-bold mt-2 text-uppercase" style="letter-spacing:.08em">Struk Pembayaran</div>
            <div class="small text-muted"><?= e(noStruk($r)) ?></div>
        </div>

        <div class="garis my-3"></div>
        <table class="table table-sm table-borderless mb-0 small">
            <tr><td class="text-muted">No. pesanan</td><td class="text-end fw-bold">#<?= (int) $r['id'] ?></td></tr>
            <tr><td class="text-muted">Tanggal</td><td class="text-end"><?= e(date('d/m/Y H:i', strtotime($r['created_at']))) ?></td></tr>
            <tr><td class="text-muted">Pemesan</td><td class="text-end"><?= e($r['pemesan']) ?></td></tr>
            <tr><td class="text-muted">Telepon</td><td class="text-end"><?= e($r['telepon']) ?></td></tr>
            <tr><td class="text-muted align-top">Alamat kirim</td><td class="text-end"><?= e($r['alamat']) ?></td></tr>
            <tr><td class="text-muted">Status pesanan</td><td class="text-end"><?= e($labelStatus) ?></td></tr>
            <tr><td class="text-muted">Metode bayar</td><td class="text-end"><?= e(labelMetode($r)) ?></td></tr>
            <tr><td class="text-muted">Status bayar</td><td class="text-end"><span class="badge text-bg-<?= e($warnaBayar) ?>"><?= e($labelBayar) ?></span></td></tr>
            <?php if ($lunas && !empty($r['dibayar_at'])): ?>
                <tr><td class="text-muted">Dibayar pada</td><td class="text-end"><?= e(date('d/m/Y H:i', strtotime($r['dibayar_at']))) ?></td></tr>
            <?php endif; ?>
        </table>
        <div class="garis my-3"></div>

        <div class="d-flex justify-content-between">
            <div>
                <div class="fw-semibold"><?= e($r['produk']) ?></div>
                <div class="small text-muted"><?= e($r['kategori']) ?> &middot; <?= (int) $r['jumlah'] ?> &times; <?= e(rupiah((int) $r['harga'])) ?></div>
            </div>
            <div class="text-nowrap"><?= e(rupiah($subtotal)) ?></div>
        </div>

        <div class="garis my-3"></div>
        <div class="d-flex justify-content-between small"><span>Subtotal</span><span><?= e(rupiah($subtotal)) ?></span></div>
        <?php if ($diskon > 0): ?>
            <div class="d-flex justify-content-between small text-success"><span>Diskon promo</span><span>- <?= e(rupiah($diskon)) ?></span></div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center mt-2">
            <span class="fw-bold">TOTAL BAYAR</span>
            <span class="h4 fw-bold mb-0"><?= e(rupiah((int) $r['total'])) ?></span>
        </div>
        <div class="garis my-3"></div>

        <div class="text-center mb-3">
            <span class="cap cap-<?= $lunas ? 'lunas' : e($r['status_bayar']) ?>"><?= $lunas ? 'LUNAS' : e(strtoupper($labelBayar)) ?></span>
        </div>
        <?php if (!$lunas): ?>
            <p class="text-center small text-muted">Struk ini akan otomatis berubah menjadi LUNAS setelah pembayaran diverifikasi admin. Lakukan pembayaran dari halaman Riwayat Pemesanan.</p>
        <?php endif; ?>

        <p class="text-center small text-muted mb-0">Terima kasih sudah memesan.<br>Simpan struk ini sebagai bukti pesanan.</p>
    </div>

    <div class="text-center mt-3 tanpa-cetak">
        <button type="button" class="btn btn-dark" onclick="window.print()"><i class="bi bi-printer"></i> Cetak / Simpan PDF</button>
        <a href="<?= $admin ? 'admin/pesanan.php' : 'pesan.php#status' ?>" class="btn btn-outline-secondary">Kembali</a>
    </div>
</div>
</body>
</html>
