<?php
/**
 * Konfigurasi dan koneksi database (PDO).
 * Sesuaikan nilai di bawah dengan pengaturan MySQL/XAMPP Anda.
 */
const DB_HOST = 'localhost';
const DB_NAME = 'kopi_nusantara';
const DB_USER = 'root';
const DB_PASS = '';

/**
 * Mengembalikan satu objek PDO yang dipakai ulang (singleton sederhana).
 */
function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            exit('Koneksi database gagal. Pastikan MySQL aktif dan database '
                . 'kopi_nusantara sudah diimport (lihat README.txt).');
        }
    }

    return $pdo;
}
