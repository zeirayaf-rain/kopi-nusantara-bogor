=====================================================================
 KOPI NUSANTARABOGOR - Website Promosi dan Pemesanan Produk Kopi Lokal
 Proyek Uji Kompetensi Junior Programmer
=====================================================================

DESKRIPSI
---------
Website coffeeshop "Kopi NusantaraBogor" untuk menampilkan produk kopi kemasan
dan minuman siap saji, lengkap dengan pemesanan online dan panel admin
(CRUD) untuk mengelola produk, kategori, pelanggan, dan transaksi.

TEKNOLOGI
---------
- PHP 8+ (PDO), MySQL/MariaDB (phpMyAdmin)
- HTML5, CSS3, JavaScript (vanilla)
- Library front-end: Bootstrap 5, Bootstrap Icons, Animate.css (via CDN)

STRUKTUR FOLDER
---------------
kopi-nusantara/
|-- index.php            Halaman Beranda (hero, slider produk, statistik, video YouTube)
|-- produk.php           Halaman Produk (filter kategori)
|-- tentang.php          Halaman Tentang Kami
|-- kontak.php           Halaman Kontak (form dengan validasi)
|-- pesan.php            Form pemesanan + kalkulasi total + cek status pesanan
|-- database.sql         Skema dan data awal database
|-- README.txt           Dokumentasi ini
|-- config/
|   `-- koneksi.php      Konfigurasi dan koneksi database (PDO)
|-- includes/
|   |-- functions.php    Fungsi bantu (escape, rupiah, flash, CSRF, dll.)
|   |-- header.php       Navbar halaman publik
|   |-- kartu_pesanan.php Komponen kartu status pesanan
|   |-- footer.php       Footer halaman publik
|   `-- kartu_produk.php Komponen kartu produk
|-- admin/               Panel admin (wajib login)
|   |-- login.php, logout.php, _auth.php, _header.php, _footer.php
|   |-- pembayaran.php   Struk masuk, bukti bayar, konfirmasi lunas
|   |-- index.php        Dashboard ringkasan
|   |-- produk.php       Daftar + hapus produk
|   |-- produk_form.php  Tambah / ubah produk (dengan unggah gambar)
|   |-- kategori.php     CRUD kategori
|   |-- pelanggan.php    Lihat / ubah / hapus pelanggan
|   `-- pesanan.php      Lihat transaksi, ubah status, hapus
`-- assets/
    |-- css/style.css    Seluruh gaya tampilan
    |-- js/main.js       Animasi, hitung total, validasi form
    `-- img/             Gambar produk (SVG) dan foto galeri; img/uploads untuk unggahan

CARA MENJALANKAN
----------------
1. Pasang XAMPP / Laragon (PHP 8+ dan MySQL), lalu aktifkan Apache dan MySQL.
2. Salin folder "kopi-nusantara" ke folder web server:
     XAMPP   -> C:\xampp\htdocs\kopi-nusantara
     Laragon -> C:\laragon\www\kopi-nusantara
3. Buka phpMyAdmin (http://localhost/phpmyadmin), pilih tab "Import",
   pilih file database.sql, lalu klik "Go/Kirim".
   (Database "kopi_nusantara" akan dibuat otomatis.)
4. Bila user/password MySQL Anda berbeda, ubah di config/koneksi.php.
5. Buka di browser:
     Website : http://localhost/kopi-nusantara/
     Admin   : http://localhost/kopi-nusantara/admin/login.php

AKUN ADMIN
----------
Username : nusantarabogor
Password : kopibogor13
(Ganti password pada tabel "admin" bila dipakai sungguhan. Tersimpan sebagai hash.)

ALUR CRUD ADMIN (sesuai soal)
-----------------------------
1. Admin login.
2. Pilih menu Produk.
3. Klik "Tambah Produk", isi data "Kopi Toraja" -> Simpan   (Create)
4. Produk tampil di daftar produk                            (Read)
5. Klik "Ubah" untuk mengganti harga atau stok               (Update)
6. Klik "Hapus" bila produk sudah tidak dijual               (Delete)
Menu Kategori, Pelanggan, dan Transaksi juga memakai operasi serupa.

FITUR UTAMA
-----------
- Desain responsif (Bootstrap grid) dan navigasi mudah.
- Pencarian nama produk di halaman Produk (bisa digabung dengan filter kategori).
- Slider produk (carousel), animasi muncul saat scroll, animasi hitung
  angka, tombol kembali ke atas, video profil.
- Form pemesanan: validasi nama, telepon, alamat, produk, jumlah (JavaScript
  dan PHP); total harga dihitung otomatis; stok berkurang saat pesanan masuk.
- Keamanan dasar: prepared statement (anti SQL injection), htmlspecialchars
  (anti XSS), token CSRF, password_hash, validasi tipe file unggahan.

PEMESANAN TANPA AKUN DAN CEK STATUS
-----------------------------------
- Pemesan TIDAK perlu daftar atau login. Klik "Pesan" / "Pesan Sekarang / Cek Pesanan" (satu tombol di navbar)
  langsung masuk ke form pemesanan (pesan.php).
- Di halaman yang sama (bagian "Status Pesanan Anda", #status) pemesan melihat status tiap pesanan (Baru, Diproses,
  Dikirim, Selesai, atau Batal) beserta progresnya.
- Cara kerja: tiap pesanan punya kode_lacak acak di database dan peramban
  pemesan mengingatnya lewat cookie, sehingga pesanan tampil otomatis di
  perangkat yang sama (data pemesan juga terisi otomatis).
- Dari HP/perangkat lain: isi nomor pesanan + nomor telepon di kotak
  "Pesan dari HP atau perangkat lain?" (dibatasi 5 percobaan salah,
  lalu ditahan 5 menit).
- Notifikasi: saat admin mengubah status di admin/pesanan.php, kotak
  notifikasi singkat muncul di kiri bawah sampai status dilihat di
  halaman Pesan.
- Database lama (sudah diimport): jalankan migrasi_tanpa_akun.sql SEKALI,
  lalu migrasi_produk.sql SEKALI (produk jadi Biji 2, Bubuk 5, Minuman 7).
  Database baru: cukup import database.sql.
- Catatan: bila cookie dihapus, pelanggan cukup memakai kotak cek di atas.

STRUK, PESAN MASUK, DAN NAMA BRAND
----------------------------------
- Struk pembayaran (struk.php): tombol "Lihat Struk" di kartu Status Pesanan
  (aman, memakai kode lacak pesanan) dan ikon struk di admin/pesanan.php.
  Halaman struk bisa dicetak atau disimpan sebagai PDF lewat dialog cetak.
- Pesan Masuk (admin/pesan_masuk.php): pesan dari form Kontak disimpan di
  tabel pesan_kontak. Admin bisa membaca, menandai dibaca, membalas lewat
  email, dan menghapus; jumlah pesan baru tampil di menu admin.
- Nama brand: Kopi NusantaraBogor (akun media sosial kopinusantarabogor di
  konstanta SOSMED). Nama database dan folder tetap kopi_nusantara agar
  konfigurasi tidak rusak.
- Database lama: jalankan migrasi_v13.sql SEKALI (tabel pesan masuk,
  Kintamani, akun admin baru). migrasi_produk.sql lama menghapus Kintamani;
  v13 menambahkannya kembali.

PROMO, WHATSAPP, DAN WARNA
--------------------------
- Banner promo berjalan di atas navbar (hover untuk berhenti). Promo, kode,
  dan syarat diatur di konstanta PROMO (includes/functions.php): satu tempat
  untuk banner, panel "Klaim Promo" di samping form Pesan, dan perhitungan
  total. Diskon dihitung ulang di server; total pesanan sudah termasuk diskon.
- Tombol WhatsApp bulat di kanan bawah: ganti nomor di konstanta WA_NOMOR
  (includes/functions.php, format 62812...). Nomor sementara = contoh.
- Warna latar produk (kartu, popup, gambar SVG produk, gambar SVG produk)
  memakai terakota gelap #8f4229 (variabel --terakota
  di style.css; di gambar SVG pada atribut fill rect pertama).
- Data pemesan contoh kedua: Siti Rahmawati (database.sql). Database lama:
  jalankan migrasi_pemesan_contoh.sql SEKALI.

GALERI, ASAL KOPI, DAN ULASAN
-----------------------------
- Navbar: Beranda, Produk, Tentang Kami, Kontak, Login Admin, Pesan Sekarang / Cek Pesanan.
  (Login Admin sebelumnya di footer, kini di navbar.)
- Galeri ada di Tentang Kami (#galeri) dan cuplikannya di Beranda.
- Asal Kopi dan Ulasan Kopi ada di halaman Produk (#asal, #ulasan).
- Testimoni pelanggan bergerak otomatis di Beranda.
- Foto memakai file lokal di assets/img/galeri/ (kopi-1.jpg ... kopi-13.jpg).
  Daftarnya ada di daftarGaleri() dan daftarAsal() (includes/functions.php).
  Ganti foto dengan menimpa file bernama sama (disarankan lebar min. 1200 px).
  Kode foto tanpa ekstensi tetap didukung: angka = Pexels, lainnya = Unsplash.
- Data ulasan: daftarUlasan() dan daftarTestimoni() (contoh/demo).

MEDIA SOSIAL DAN PETA
---------------------
- Ikon Instagram, TikTok, Facebook, dan X muncul di footer, Beranda, dan
  halaman Kontak. Ganti URL akun di konstanta SOSMED pada
  includes/functions.php (cukup satu tempat).
- Peta di halaman Kontak adalah contoh (Bogor). Ganti alamat pada atribut
  src iframe di kontak.php dengan lokasi kedai Anda.

PEMBAYARAN (QRIS / TRANSFER BANK), STRUK OTOMATIS, DAN ADMIN PEMBAYARAN
----------------------------------------------------------------------
Alur:
  1. Pemesan memilih metode di form Pesan: QRIS atau Transfer Bank (pilih BCA/BRI/Mandiri).
  2. Begitu pesanan dikirim, struk (No. INV-tanggal-nomor) otomatis masuk ke
     "Riwayat Pemesanan & Struk" di pesan.php#status, berstatus "Belum dibayar",
     lengkap dengan QRIS atau nomor rekening (ada tombol Salin).
  3. Pemesan membayar lalu mengunggah foto bukti (JPG/PNG/WEBP, maks. 3 MB)
     -> status "Menunggu verifikasi".
  4. Admin membuka menu "Struk & Pembayaran" (admin/pembayaran.php): melihat
     semua struk masuk, bukti bayar, filter Menunggu/Belum/Lunas, lalu klik
     "Lunas". Pesanan baru otomatis naik menjadi "Diproses" dan struk pemesan
     berubah menjadi stempel LUNAS. Bukti yang tidak sah bisa "Tolak" (pemesan
     boleh unggah ulang).
  5. Dashboard admin kini menghitung pendapatan hanya dari pesanan LUNAS.
Yang HARUS Anda ganti:
  - Rekening bank: konstanta REKENING di includes/functions.php (nomor sekarang contoh).
  - QRIS asli: simpan gambar QRIS kedai sebagai assets/img/qris.png (atau .jpg/.webp).
    Sebelum itu tampil gambar penanda assets/img/qris-contoh.svg.
  - Nama merchant: konstanta QRIS_NAMA.
Database lama: jalankan migrasi_v14.sql SEKALI (kolom metode_bayar, bank,
status_bayar, bukti_bayar, dibayar_at). Database baru cukup import database.sql.
Catatan: verifikasi pembayaran dilakukan manual oleh admin (cocokkan dengan
mutasi rekening / laporan QRIS). Verifikasi otomatis memerlukan payment
gateway (mis. Midtrans/Xendit) dan akun merchant.
Folder assets/img/uploads/bukti harus dapat ditulis.

CATATAN
-------
- Library Bootstrap/Animate.css dimuat dari CDN sehingga perlu internet.
- Video profil di Beranda (3 video YouTube) memakai daftar $videoProfil di
  index.php. Tambah/ganti ID video di array tersebut (true = vertikal/Shorts).
- Agar unggah gambar berfungsi, folder assets/img/uploads harus dapat ditulis.
- Validasi kode: gunakan https://validator.w3.org (HTML) dan
  https://jigsaw.w3.org/css-validator (CSS) pada hasil render halaman.
