/**
 * Kopi Nusantara Bogor - JavaScript utama
 * Fitur: efek muncul saat scroll, animasi hitung angka,
 *        tombol kembali ke atas, lightbox galeri, dan kalkulasi total pemesanan.
 */
document.addEventListener('DOMContentLoaded', function () {
    inisialisasiReveal();
    inisialisasiHitungAngka();
    inisialisasiTombolAtas();
    inisialisasiFormPesan();
    inisialisasiLightbox();
    inisialisasiModalInfo();
    inisialisasiModalProduk();
    inisialisasiTombolSalin();
});

/** Tombol [data-salin] menyalin teks (mis. nomor rekening) ke papan klip. */
function inisialisasiTombolSalin() {
    document.addEventListener('click', function (ev) {
        var tombol = ev.target.closest('[data-salin]');
        if (!tombol) { return; }
        var teks = tombol.dataset.salin;
        var awal = tombol.innerHTML;
        function selesai() {
            tombol.innerHTML = '<i class="bi bi-check2"></i> Tersalin';
            setTimeout(function () { tombol.innerHTML = awal; }, 1800);
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(teks).then(selesai, function () { window.prompt('Salin nomor ini:', teks); });
        } else {
            window.prompt('Salin nomor ini:', teks);
        }
    });
}

/** Format angka menjadi Rupiah, contoh: Rp 85.000 */
function formatRupiah(angka) {
    return 'Rp ' + Number(angka).toLocaleString('id-ID');
}

/** Elemen ber-class .reveal tampil dengan animasi saat masuk layar. */
function inisialisasiReveal() {
    var elemen = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) {
        elemen.forEach(function (el) { el.classList.add('terlihat'); });
        return;
    }
    var pengamat = new IntersectionObserver(function (daftar) {
        daftar.forEach(function (item) {
            if (item.isIntersecting) {
                item.target.classList.add('terlihat');
                pengamat.unobserve(item.target);
            }
        });
    }, { threshold: 0.15 });
    elemen.forEach(function (el) { pengamat.observe(el); });
}

/** Angka statistik (.hitung) naik dari 0 ke nilai data-target. */
function inisialisasiHitungAngka() {
    var penghitung = document.querySelectorAll('.hitung');
    if (!penghitung.length || !('IntersectionObserver' in window)) {
        penghitung.forEach(function (el) { el.textContent = el.dataset.target; });
        return;
    }
    var pengamat = new IntersectionObserver(function (daftar) {
        daftar.forEach(function (item) {
            if (!item.isIntersecting) { return; }
            animasiAngka(item.target);
            pengamat.unobserve(item.target);
        });
    }, { threshold: 0.6 });
    penghitung.forEach(function (el) { pengamat.observe(el); });
}

function animasiAngka(el) {
    var target = parseInt(el.dataset.target, 10) || 0;
    var durasi = 1200;
    var mulai = null;

    function langkah(waktu) {
        if (mulai === null) { mulai = waktu; }
        var progres = Math.min((waktu - mulai) / durasi, 1);
        el.textContent = Math.floor(progres * target).toLocaleString('id-ID');
        if (progres < 1) { requestAnimationFrame(langkah); }
    }
    requestAnimationFrame(langkah);
}

/** Tombol melayang untuk kembali ke bagian atas halaman. */
function inisialisasiTombolAtas() {
    var tombol = document.getElementById('btnAtas');
    if (!tombol) { return; }

    window.addEventListener('scroll', function () {
        tombol.classList.toggle('tampil', window.scrollY > 300);
    });
    tombol.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

/** Isi modal lightbox dengan data foto yang diklik (data-src, data-judul, data-deskripsi). */
function inisialisasiLightbox() {
    var modal = document.getElementById('modalGaleri');
    if (!modal) { return; }

    modal.addEventListener('show.bs.modal', function (ev) {
        var tombol = ev.relatedTarget;
        if (!tombol) { return; }
        var gambar = document.getElementById('gambarGaleri');
        gambar.src = tombol.dataset.src;
        gambar.alt = tombol.dataset.judul;
    });
}

/** Isi popup info (perbedaan kopi & tips seduh) dari data-* kartu yang diklik. */
function inisialisasiModalInfo() {
    var modal = document.getElementById('modalInfo');
    if (!modal) { return; }

    modal.addEventListener('show.bs.modal', function (ev) {
        var kartu = ev.relatedTarget;
        if (!kartu) { return; }
        document.getElementById('judulInfo').textContent = kartu.dataset.judul;
        document.getElementById('ringkasInfo').textContent = kartu.dataset.ringkas;
        document.getElementById('ikonInfo').className = 'bi ' + kartu.dataset.ikon;

        var daftar = document.getElementById('poinInfo');
        daftar.innerHTML = '';
        var urut = kartu.dataset.urut === '1';
        (kartu.dataset.poin || '').split('~').forEach(function (baris, i) {
            var bagian = baris.split('|');
            var li = document.createElement('li');
            var label = document.createElement('strong');
            label.textContent = urut ? (i + 1) + '. ' + bagian[0] : bagian[0];
            var isi = document.createElement('span');
            isi.textContent = bagian[1] || '';
            li.appendChild(label);
            li.appendChild(isi);
            daftar.appendChild(li);
        });
    });
}

/** Hitung total harga otomatis pada form pemesanan dan validasi ringan. */
function inisialisasiFormPesan() {
    var form = document.getElementById('formPesan');
    if (!form) { return; }

    var pilihan = document.getElementById('produk_id');
    var jumlah = document.getElementById('jumlah');
    var labelTotal = document.getElementById('totalHarga');

    var kolomPromo = document.getElementById('promo');
    var infoPromo = document.getElementById('infoPromo');
    var promoData = {};
    try { promoData = JSON.parse(form.dataset.promo || '{}'); } catch (e) { promoData = {}; }

    /** Aturan sama dengan hitungPromo() di PHP (server tetap menghitung ulang). */
    function hitungDiskon(kode, kategori, sub) {
        var p = promoData[kode];
        if (!kode) { return { diskon: 0, pesan: '' }; }
        if (!p) { return { diskon: 0, pesan: 'Kode promo tidak dikenal.' }; }
        if (sub <= 0) { return { diskon: 0, pesan: 'Pilih produk dulu untuk memakai kode ini.' }; }
        if (p.kategori && p.kategori !== kategori) { return { diskon: 0, pesan: 'Kode ini hanya berlaku untuk ' + p.kategori + '.' }; }
        if (sub < p.min) { return { diskon: 0, pesan: 'Minimal belanja ' + formatRupiah(p.min) + ' untuk kode ini.' }; }
        var d = p.tipe === 'persen' ? Math.floor(sub * p.nilai / 100) : Math.min(p.nilai, sub);
        return { diskon: d, pesan: '' };
    }

    function hitungTotal() {
        var opsi = pilihan.options[pilihan.selectedIndex];
        var harga = parseInt(opsi && opsi.dataset.harga, 10) || 0;
        var qty = parseInt(jumlah.value, 10) || 0;
        var sub = harga * qty;
        var kode = kolomPromo ? kolomPromo.value.trim().toUpperCase() : '';
        var hasil = hitungDiskon(kode, opsi && opsi.dataset.kategori, sub);

        document.getElementById('subtotalHarga').textContent = formatRupiah(sub);
        document.getElementById('barisDiskon').classList.toggle('d-none', hasil.diskon === 0);
        document.getElementById('diskonHarga').textContent = '- ' + formatRupiah(hasil.diskon);
        labelTotal.textContent = formatRupiah(sub - hasil.diskon);

        if (infoPromo) {
            infoPromo.className = 'small mt-1 ' + (hasil.pesan ? 'text-danger' : 'text-success');
            infoPromo.textContent = hasil.pesan || (hasil.diskon ? 'Promo ' + kode + ' terpasang, hemat ' + formatRupiah(hasil.diskon) + '.' : '');
        }

        // Batasi jumlah maksimum sesuai stok produk terpilih
        var stok = parseInt(opsi && opsi.dataset.stok, 10);
        if (stok) { jumlah.max = stok; }
    }

    if (kolomPromo) { kolomPromo.addEventListener('input', hitungTotal); }
    document.querySelectorAll('[data-klaim]').forEach(function (tombol) {
        tombol.addEventListener('click', function () {
            kolomPromo.value = tombol.dataset.klaim;
            hitungTotal();
            document.querySelectorAll('[data-klaim]').forEach(function (t) { t.textContent = 'Klaim'; });
            tombol.textContent = 'Terpasang';
            form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    pilihan.addEventListener('change', hitungTotal);
    jumlah.addEventListener('input', hitungTotal);
    hitungTotal();

    // Pilihan bank hanya tampil bila metode = transfer bank
    var kotakBank = document.getElementById('pilihBank');
    form.querySelectorAll('input[name="metode"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            if (kotakBank) { kotakBank.classList.toggle('d-none', radio.value !== 'transfer' || !radio.checked); }
        });
    });

    // Validasi sisi klien sebelum form dikirim (server tetap memvalidasi ulang)
    form.addEventListener('submit', function (ev) {
        var valid = true;
        var aturan = [
            ['nama', function (v) { return v.trim().length >= 3; }],
            ['telepon', function (v) { return /^[0-9+\-\s]{8,20}$/.test(v.trim()); }],
            ['alamat', function (v) { return v.trim().length >= 10; }],
            ['produk_id', function (v) { return v !== ''; }],
            ['jumlah', function (v) { return parseInt(v, 10) >= 1; }]
        ];

        aturan.forEach(function (item) {
            var kolom = document.getElementById(item[0]);
            var ok = item[1](kolom.value);
            kolom.classList.toggle('is-invalid', !ok);
            if (!ok) { valid = false; }
        });

        if (!valid) { ev.preventDefault(); }
    });
}

/** Klik kartu produk (halaman Produk) membuka popup detail produk. */
function inisialisasiModalProduk() {
    var modalEl = document.getElementById('modalProduk');
    if (!modalEl) { return; }

    function buka(kartu) {
        var d = kartu.dataset;
        var gambar = document.getElementById('mpGambar');
        gambar.src = d.gambar;
        gambar.alt = d.nama;
        document.getElementById('mpKategori').textContent = d.kategori;
        document.getElementById('mpNama').textContent = d.nama;
        document.getElementById('mpDeskripsi').textContent = d.deskripsi;
        document.getElementById('mpHarga').textContent = d.harga;

        var stok = parseInt(d.stok, 10) || 0;
        document.getElementById('mpStok').innerHTML = stok > 0
            ? '<i class="bi bi-check-circle-fill text-success"></i> Stok tersedia: ' + stok
            : '<i class="bi bi-x-circle-fill text-danger"></i> Stok habis';

        var tombol = document.getElementById('mpPesan');
        tombol.style.display = stok > 0 ? '' : 'none';
        tombol.href = 'pesan.php?produk=' + d.id;

        bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    document.addEventListener('click', function (ev) {
        if (ev.target.closest('a, button')) { return; }
        var kartu = ev.target.closest('.kartu-produk[data-id]');
        if (kartu) { buka(kartu); }
    });
    document.addEventListener('keydown', function (ev) {
        if ((ev.key === 'Enter' || ev.key === ' ') && ev.target.matches && ev.target.matches('.kartu-produk[data-id]')) {
            ev.preventDefault();
            buka(ev.target);
        }
    });
}
