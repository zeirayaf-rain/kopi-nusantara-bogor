-- ============================================================
-- Tambah 1 data pemesan contoh (Siti Rahmawati) + 1 pesanannya.
-- Untuk database yang SUDAH diimport. Jalankan SEKALI di phpMyAdmin.
-- Syarat: migrasi_produk.sql sudah dijalankan (produk Vanilla Latte ada).
-- ============================================================
USE kopi_nusantara;

INSERT INTO pelanggan (nama, alamat, telepon) VALUES
('Siti Rahmawati', 'Jl. Pajajaran No. 25, Bogor', '081298765432');

INSERT INTO pesanan (pelanggan_id, produk_id, jumlah, total, status, status_dilihat, kode_lacak) VALUES
(LAST_INSERT_ID(), (SELECT id FROM produk WHERE nama = 'Es Kopi Susu Vanilla Latte'), 3, 72000, 'diproses', 'diproses', 'e5f6a7b8');
