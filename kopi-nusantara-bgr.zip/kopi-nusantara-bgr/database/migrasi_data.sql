-- ============================================================
-- Migrasi v13 untuk database kopi_nusantara yang SUDAH diimport.
-- Isi: tabel Pesan Masuk, produk Kopi Kintamani Bali (biji), dan akun
-- admin baru (username nusantarabogor, password kopibogor13; akun lama
-- "admin" dihapus). Jalankan SEKALI di phpMyAdmin (tab SQL).
-- Database baru cukup import database.sql.
-- ============================================================
USE kopi_nusantara;

CREATE TABLE IF NOT EXISTS pesan_kontak (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  pesan TEXT NOT NULL,
  dibaca TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO produk (kategori_id, nama, deskripsi, harga, stok, gambar)
SELECT k.id, 'Kopi Kintamani Bali', 'Arabika Kintamani dengan sentuhan citrus segar dan manis alami. Kemasan 250 gram.', 95000, 25, 'produk-kintamani.svg'
FROM kategori k
WHERE k.nama = 'Kopi Biji'
  AND NOT EXISTS (SELECT 1 FROM produk WHERE nama = 'Kopi Kintamani Bali');

INSERT INTO admin (username, password, nama_lengkap) VALUES
('nusantara bogor', '$2y$10$V7y19Fnj9OOnzhpjc5GFaOdBibXQ4Aad4HNaURhWo/Z5dyEcrwJX2', 'Administrator')
ON DUPLICATE KEY UPDATE password = VALUES(password);
DELETE FROM admin WHERE username = 'admin';
