-- ============================================================
-- Migrasi v14 untuk database kopi_nusantara yang SUDAH diimport.
-- Isi: kolom pembayaran (QRIS / transfer bank) pada tabel pesanan.
-- Jalankan SEKALI di phpMyAdmin (tab SQL). Database baru cukup
-- import database.sql.
-- ============================================================
USE kopi_nusantara;

ALTER TABLE pesanan
  ADD COLUMN metode_bayar ENUM('qris','transfer') NOT NULL DEFAULT 'qris' AFTER kode_lacak,
  ADD COLUMN bank VARCHAR(20) NOT NULL DEFAULT '' AFTER metode_bayar,
  ADD COLUMN status_bayar ENUM('belum','menunggu','lunas') NOT NULL DEFAULT 'belum' AFTER bank,
  ADD COLUMN bukti_bayar VARCHAR(150) NOT NULL DEFAULT '' AFTER status_bayar,
  ADD COLUMN dibayar_at DATETIME NULL DEFAULT NULL AFTER bukti_bayar;

-- Pesanan lama yang sudah selesai dianggap lunas
UPDATE pesanan SET status_bayar = 'lunas', dibayar_at = created_at WHERE status = 'selesai';
