-- ============================================================
-- Database  : kopi_nusantara
-- Cara pakai: buka phpMyAdmin > tab "Import" > pilih file ini,
--             atau jalankan: mysql -u root < database.sql
-- Akun admin: username "nusantarabogor" | password "kopibogor13"
-- ============================================================

CREATE DATABASE IF NOT EXISTS kopi_nusantara
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kopi_nusantara;

DROP TABLE IF EXISTS pesan_kontak;
DROP TABLE IF EXISTS pesanan;
DROP TABLE IF EXISTS akun; -- tabel lama (fitur akun sudah dihapus)
DROP TABLE IF EXISTS pelanggan;
DROP TABLE IF EXISTS produk;
DROP TABLE IF EXISTS kategori;
DROP TABLE IF EXISTS admin;

-- Tabel admin (untuk login halaman admin)
CREATE TABLE admin (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nama_lengkap VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- Tabel kategori produk
CREATE TABLE kategori (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- Tabel produk
CREATE TABLE produk (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kategori_id INT UNSIGNED NOT NULL,
  nama VARCHAR(100) NOT NULL,
  deskripsi TEXT NOT NULL,
  harga INT UNSIGNED NOT NULL,
  stok INT UNSIGNED NOT NULL DEFAULT 0,
  gambar VARCHAR(150) NOT NULL DEFAULT 'produk-default.svg',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_produk_kategori FOREIGN KEY (kategori_id)
    REFERENCES kategori(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Tabel pelanggan
CREATE TABLE pelanggan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  alamat TEXT NOT NULL,
  telepon VARCHAR(20) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabel pesanan / transaksi
CREATE TABLE pesanan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pelanggan_id INT UNSIGNED NOT NULL,
  produk_id INT UNSIGNED NOT NULL,
  jumlah INT UNSIGNED NOT NULL,
  total INT UNSIGNED NOT NULL,
  status ENUM('baru','diproses','dikirim','selesai','batal') NOT NULL DEFAULT 'baru',
  status_dilihat VARCHAR(10) NOT NULL DEFAULT 'baru',
  kode_lacak CHAR(8) NOT NULL DEFAULT '', -- kode acak untuk melacak pesanan tanpa akun
  metode_bayar ENUM('qris','transfer') NOT NULL DEFAULT 'qris',
  bank VARCHAR(20) NOT NULL DEFAULT '',          -- bank tujuan (khusus transfer)
  status_bayar ENUM('belum','menunggu','lunas') NOT NULL DEFAULT 'belum',
  bukti_bayar VARCHAR(150) NOT NULL DEFAULT '',  -- nama file bukti transfer/QRIS
  dibayar_at DATETIME NULL DEFAULT NULL,         -- waktu admin mengonfirmasi lunas
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pesanan_pelanggan FOREIGN KEY (pelanggan_id)
    REFERENCES pelanggan(id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_pesanan_produk FOREIGN KEY (produk_id)
    REFERENCES produk(id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabel pesan masuk dari form Kontak (dibaca admin)
CREATE TABLE pesan_kontak (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  pesan TEXT NOT NULL,
  dibaca TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------- Data awal ----------------
INSERT INTO admin (username, password, nama_lengkap) VALUES
('nusantara bogor', '$2y$10$V7y19Fnj9OOnzhpjc5GFaOdBibXQ4Aad4HNaURhWo/Z5dyEcrwJX2', 'Administrator');

INSERT INTO kategori (nama) VALUES
('Kopi Biji'), ('Kopi Bubuk'), ('Minuman Siap Saji');

INSERT INTO produk (kategori_id, nama, deskripsi, harga, stok, gambar) VALUES
(1, 'Kopi Gayo Aceh', 'Arabika dataran tinggi Gayo dengan aroma floral, body tebal, dan after taste cokelat. Kemasan 250 gram.', 85000, 40, 'produk-gayo.svg'),
(1, 'Kopi Flores Bajawa', 'Arabika Bajawa bernuansa karamel dan rempah, keasaman lembut. Kemasan 250 gram.', 90000, 30, 'produk-flores.svg'),
(1, 'Kopi Kintamani Bali', 'Arabika Kintamani dengan sentuhan citrus segar dan manis alami. Kemasan 250 gram.', 95000, 25, 'produk-kintamani.svg'),
(2, 'Kopi Robusta Lampung', 'Robusta bubuk berkarakter kuat, pahit mantap, cocok untuk kopi tubruk. Kemasan 200 gram.', 45000, 60, 'produk-lampung.svg'),
(3, 'Es Kopi Susu Gula Aren', 'Espresso, susu segar, dan gula aren asli dalam botol 250 ml. Siap minum, simpan dingin.', 22000, 80, 'produk-eskopi.svg'),
(3, 'Kopi Hitam Dingin (Cold Brew)', 'Cold brew diseduh 16 jam, rasa halus tanpa gula. Botol 250 ml.', 25000, 50, 'produk-coldbrew.svg'),
(2, 'Kopi Bubuk Gayo Aceh', 'Arabika Gayo giling halus dengan aroma floral dan after taste cokelat. Cocok untuk V60 dan tubruk halus. Kemasan 200 gram.', 65000, 45, 'produk-bubuk-gayo.svg'),
(2, 'Kopi Bubuk Flores Bajawa', 'Arabika Bajawa giling medium, nuansa karamel dan rempah dengan keasaman lembut. Kemasan 200 gram.', 68000, 40, 'produk-bubuk-flores.svg'),
(2, 'Kopi Bubuk Robusta Temanggung', 'Robusta Temanggung bubuk dengan body tebal dan aroma tembakau manis, mantap untuk kopi tubruk dan kopi susu. Kemasan 200 gram.', 42000, 55, 'produk-bubuk-temanggung.svg'),
(2, 'Kopi Tubruk Nusantara Blend', 'Racikan arabika dan robusta pilihan, giling kasar khusus seduh tubruk. Pahit seimbang dan wangi. Kemasan 250 gram.', 48000, 70, 'produk-bubuk-blend.svg'),
(3, 'Es Kopi Susu Vanilla Latte', 'Espresso, susu segar, dan sirup vanila yang lembut. Botol 250 ml, simpan dingin.', 24000, 70, 'produk-vanilla.svg'),
(3, 'Es Kopi Caramel Latte', 'Espresso dengan saus karamel dan susu segar, manis legit tapi tidak berlebihan. Botol 250 ml.', 25000, 65, 'produk-karamel.svg'),
(3, 'Es Mocha Cokelat', 'Perpaduan espresso dan cokelat pekat dengan susu segar. Botol 250 ml, simpan dingin.', 26000, 60, 'produk-mocha.svg'),
(3, 'Es Kopi Susu Pandan', 'Kopi susu dengan aroma pandan wangi khas Nusantara. Botol 250 ml, siap minum.', 23000, 60, 'produk-pandan.svg'),
(3, 'Es Americano Jeruk', 'Americano dingin dengan perasan jeruk segar, ringan dan menyegarkan tanpa susu. Botol 250 ml.', 22000, 55, 'produk-americano.svg');

INSERT INTO pelanggan (nama, alamat, telepon) VALUES
('Budi Santoso', 'Jl. Merdeka No. 10, Bogor', '081234567890'),
('Siti Rahmawati', 'Jl. Pajajaran No. 25, Bogor', '081298765432');

INSERT INTO pesanan (pelanggan_id, produk_id, jumlah, total, status, kode_lacak, metode_bayar, bank, status_bayar) VALUES
(1, 1, 2, 170000, 'baru', 'a1b2c3d4', 'transfer', 'BCA', 'belum');
INSERT INTO pesanan (pelanggan_id, produk_id, jumlah, total, status, status_dilihat, kode_lacak, metode_bayar, status_bayar, dibayar_at) VALUES
(2, (SELECT id FROM produk WHERE nama = 'Es Kopi Susu Vanilla Latte'), 3, 72000, 'diproses', 'diproses', 'e5f6a7b8', 'qris', 'lunas', NOW());
