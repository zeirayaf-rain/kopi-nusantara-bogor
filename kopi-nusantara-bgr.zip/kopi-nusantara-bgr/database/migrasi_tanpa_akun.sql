-- ============================================================
-- Migrasi untuk database kopi_nusantara yang SUDAH diimport sebelumnya.
-- Menghapus fitur akun pemesan; pesanan dilacak tanpa login memakai
-- kode_lacak. Jalankan SEKALI di phpMyAdmin (tab SQL / Import).
-- Data pesanan lama tidak terhapus (pesanan lama tidak bisa dilacak
-- pelanggan karena belum punya kode; admin tetap melihatnya).
-- (Database baru cukup import database.sql, tidak perlu file ini.)
-- ============================================================
USE kopi_nusantara;

ALTER TABLE pesanan DROP FOREIGN KEY fk_pesanan_akun;
ALTER TABLE pesanan DROP COLUMN akun_id;
ALTER TABLE pesanan ADD COLUMN kode_lacak CHAR(8) NOT NULL DEFAULT '' AFTER status_dilihat;
DROP TABLE IF EXISTS akun;
