-- ============================================================
-- Migrasi produk untuk database kopi_nusantara yang SUDAH diimport.
-- Hasil akhir: Biji Kopi 2, Kopi Bubuk 5, Minuman Siap Saji 7 produk.
-- Jalankan SEKALI di phpMyAdmin (tab SQL). Database baru cukup
-- import database.sql.
-- ============================================================
USE kopi_nusantara;

-- Kintamani dihapus hanya bila belum pernah dipesan (agar riwayat pesanan aman)
DELETE FROM produk
 WHERE nama = 'Kopi Kintamani Bali'
   AND id NOT IN (SELECT produk_id FROM (SELECT produk_id FROM pesanan) AS p);

INSERT INTO produk (kategori_id, nama, deskripsi, harga, stok, gambar) VALUES
(2, 'Kopi Bubuk Gayo Aceh', 'Arabika Gayo giling halus dengan aroma floral dan after taste cokelat. Cocok untuk V60 dan tubruk halus. Kemasan 200 gram.', 65000, 45, 'produk-bubuk-gayo.svg'),
(2, 'Kopi Bubuk Flores Bajawa', 'Arabika Bajawa giling medium, nuansa karamel dan rempah dengan keasaman lembut. Kemasan 200 gram.', 68000, 40, 'produk-bubuk-flores.svg'),
(2, 'Kopi Bubuk Robusta Temanggung', 'Robusta Temanggung bubuk dengan body tebal dan aroma tembakau manis, mantap untuk kopi tubruk dan kopi susu. Kemasan 200 gram.', 42000, 55, 'produk-bubuk-temanggung.svg'),
(2, 'Kopi Tubruk Nusantara Blend', 'Racikan arabika dan robusta pilihan, giling kasar khusus seduh tubruk. Pahit seimbang dan wangi. Kemasan 250 gram.', 48000, 70, 'produk-bubuk-blend.svg'),
(3, 'Es Kopi Susu Vanilla Latte', 'Espresso, susu segar, dan sirup vanila yang lembut. Botol 250 ml, simpan dingin.', 24000, 70, 'produk-vanilla.svg'),
(3, 'Es Kopi Caramel Latte', 'Espresso dengan saus karamel dan susu segar, manis legit tapi tidak berlebihan. Botol 250 ml.', 25000, 65, 'produk-karamel.svg'),
(3, 'Es Mocha Cokelat', 'Perpaduan espresso dan cokelat pekat dengan susu segar. Botol 250 ml, simpan dingin.', 26000, 60, 'produk-mocha.svg'),
(3, 'Es Kopi Susu Pandan', 'Kopi susu dengan aroma pandan wangi khas Nusantara. Botol 250 ml, siap minum.', 23000, 60, 'produk-pandan.svg'),
(3, 'Es Americano Jeruk', 'Americano dingin dengan perasan jeruk segar, ringan dan menyegarkan tanpa susu. Botol 250 ml.', 22000, 55, 'produk-americano.svg');
