<?php
/** Halaman Beranda */
$judul = 'Beranda';
$aktif = 'beranda';
require __DIR__ . '/includes/header.php';

$unggulan = ambilProduk(null, 6);
$slide    = array_chunk($unggulan, 3); // 3 produk per slide
?>

<!-- HERO -->
<section class="hero-foto-bg" style="background-image:url('<?= e(urlFoto('kopi-8.jpg', 1800)) ?>')">
    <div class="container hero-isi text-white">
        <p class="mb-2 hero-lokasi"><i class="bi bi-geo-alt-fill"></i> Bogor, Jawa Barat</p>
        <h1 class="display-3 fw-bold animate__animated animate__fadeInUp">Selamat Datang di <em>Kopi Nusantara Bogor</em></h1>
        <p class="lead col-lg-6 px-0">Dari ujung Sumatra hingga Papua, kami merangkai cita rasa Indonesia dalam satu cangkir.
Kopi Nusantara bukan sekadar kedai kopi, ini adalah rumah bagi para penikmat kopi lokal yang jujur, hangat, dan penuh cerita. Biji kopi pilihan dari Aceh, Flores, Bali, hingga Lampung. Tersedia dalam kemasan dan minuman siap saji.</p>
        <div class="d-flex flex-wrap gap-2 mb-4">
            <a href="produk.php" class="btn btn-kopi btn-lg">Lihat Produk</a>
            <a href="pesan.php" class="btn btn-outline-light btn-lg">Pesan Online</a>
        </div>
        <div class="d-flex flex-wrap gap-3 small hero-info">
            <span><i class="bi bi-clock-fill"></i> Buka Senin - Minggu, 09.00 - 22.00 WIB</span>
            <span><i class="bi bi-star-fill"></i> Rating 4,9 dari pelanggan</span>
        </div>
    </div>
</section>

<!-- KEUNGGULAN -->
<section class="container py-5">
    <div class="row g-4 text-center">
        <?php
        $keunggulan = [
            ['bi-flower1',  'Petani Lokal',     'Dibeli langsung dari petani dengan harga adil.'],
            ['bi-fire',     'Roasting Segar',   'Disangrai setiap pekan agar aroma tetap maksimal.'],
            ['bi-truck',    'Kirim Cepat',      'Dikemas rapat dan dikirim ke seluruh Indonesia.'],
        ];
        foreach ($keunggulan as [$ikon, $judulK, $teks]): ?>
            <div class="col-md-4 reveal">
                <div class="ikon-bulat mx-auto mb-3"><i class="bi <?= $ikon ?>"></i></div>
                <h2 class="h5 fw-bold"><?= $judulK ?></h2>
                <p class="text-muted mb-0"><?= $teks ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- SLIDER PRODUK -->
<section class="bg-krem py-5">
    <div class="container">
        <h2 class="text-center fw-bold mb-1">Produk Unggulan</h2>
        <p class="text-center text-muted mb-4">Geser untuk melihat pilihan favorit pelanggan kami</p>

        <?php if (empty($slide)): ?>
            <p class="text-center text-muted">Belum ada produk.</p>
        <?php else: ?>
            <div id="sliderProduk" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
                <div class="carousel-inner pb-5">
                    <?php foreach ($slide as $i => $grup): ?>
                        <div class="carousel-item<?= $i === 0 ? ' active' : '' ?>">
                            <div class="row g-4 justify-content-center">
                                <?php foreach ($grup as $p): ?>
                                    <div class="col-12 col-sm-6 col-lg-4">
                                        <?php include __DIR__ . '/includes/kartu_produk.php'; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if (count($slide) > 1): ?>
                    <div class="carousel-indicators slider-dots">
                        <?php foreach ($slide as $i => $_): ?>
                            <button type="button" data-bs-target="#sliderProduk" data-bs-slide-to="<?= $i ?>"
                                    class="<?= $i === 0 ? 'active' : '' ?>" aria-label="Slide <?= $i + 1 ?>"></button>
                        <?php endforeach; ?>
                    </div>
                    <button class="carousel-control-prev slider-ctrl" type="button"
                            data-bs-target="#sliderProduk" data-bs-slide="prev" aria-label="Sebelumnya">
                        <i class="bi bi-chevron-left"></i>
                    </button>
                    <button class="carousel-control-next slider-ctrl" type="button"
                            data-bs-target="#sliderProduk" data-bs-slide="next" aria-label="Berikutnya">
                        <i class="bi bi-chevron-right"></i>
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="text-center"><a href="produk.php" class="btn btn-outline-kopi">Lihat Semua Produk</a></div>
    </div>
</section>

<!-- GALERI TEMPAT -->
<section class="container py-5">
    <h2 class="text-center fw-bold mb-1">Suasana Kopi Nusantara Bogor</h2>
    <p class="text-center text-muted mb-4">Tempat luar, ruang dalam, area duduk, hingga pemandangan kebun kopi</p>

    <div class="galeri-grid galeri-beranda">
        <?php foreach (array_slice(daftarGaleri(), 0, 5) as $g): ?>
            <?php include __DIR__ . '/includes/galeri_item.php'; ?>
        <?php endforeach; ?>
        <a href="tentang.php#galeri" class="galeri-lainnya reveal">
            <i class="bi bi-images"></i>
            <span>Lihat Galeri Lengkap</span>
        </a>
    </div>
</section>

<!-- ASAL KOPI -->
<section class="bg-krem py-5">
    <div class="container">
        <h2 class="text-center fw-bold mb-1">Dari Mana Kopi Kami Berasal</h2>
        <p class="text-center text-muted mb-4">Empat daerah penghasil kopi yang kami pilih</p>
        <div class="row g-4">
            <?php foreach (daftarAsal() as $a): ?>
                <div class="col-sm-6 col-lg-3 reveal">
                    <a href="produk.php#asal-<?= e(strtolower(str_replace(' ', '-', $a['nama']))) ?>" class="asal-mini">
                        <img src="<?= e(urlFoto($a['foto'], 600)) ?>" alt="Kopi <?= e($a['nama']) ?>" loading="lazy">
                        <span class="asal-mini-isi">
                            <strong><?= e($a['nama']) ?></strong>
                            <small><?= e($a['jenis']) ?> &middot; <?= e($a['tinggi']) ?></small>
                        </span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-4"><a href="produk.php#asal" class="btn btn-outline-kopi">Jelajahi Asal Kopi</a></div>
    </div>
</section>

<!-- ULASAN PELANGGAN (bergerak otomatis dari kanan ke kiri) -->
<section class="py-5 overflow-hidden">
    <div class="container">
        <h2 class="text-center fw-bold mb-1">Kata Mereka tentang Kopi Nusantara Bogor</h2>
        <p class="text-center text-muted mb-4">Ulasan contoh dari pelanggan. Catatan rasa tiap produk ada di <a href="produk.php#ulasan">halaman Produk</a>.</p>
    </div>
    <div class="marquee" aria-label="Ulasan pelanggan">
        <div class="marquee-trek">
            <?php foreach ([false, true] as $salinan): ?>
                <?php foreach (daftarTestimoni() as [$nama, $profesi, $bintang, $isi]): ?>
                    <div class="marquee-item"<?= $salinan ? ' aria-hidden="true"' : '' ?>>
                        <?php include __DIR__ . '/includes/testimoni_kartu.php'; ?>
                    </div>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- STATISTIK (animasi hitung naik) -->
<section class="container py-5">
    <div class="row text-center g-4">
        <?php
        $statistik = [[1200, 'Pelanggan Puas'], [15, 'Varian Kopi'], [8, 'Daerah Asal'], [3, 'Tahun Berdiri']];
        foreach ($statistik as [$angka, $label]): ?>
            <div class="col-6 col-md-3 reveal">
                <div class="display-5 fw-bold text-aksen"><span class="hitung" data-target="<?= $angka ?>">0</span>+</div>
                <div class="text-muted"><?= $label ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- VIDEO PROFIL -->
<section class="container pb-4">
    <h2 class="text-center fw-bold mb-4 reveal">Video Profil Singkat</h2>
    <?php
    // Daftar video YouTube: [id, judul, vertikal?]. Tambah/ganti ID di sini.
    $videoProfil = [
        ['ECYhisX_GnY', 'Video profil Kopi Nusantara Bogor', true],
        ['g1m12gFF_Ts', 'Video profil Kopi Nusantara Bogor (Shorts)', true],
        ['BL8s1vyEvf8', 'Video profil Kopi Nusantara Bogor (YouTube)', false],
    ];
    ?>
    <div class="row g-4 justify-content-center align-items-start">
        <?php foreach ($videoProfil as [$vid, $vJudul, $vertikal]): ?>
            <div class="<?= $vertikal ? 'col-sm-6 col-lg-3' : 'col-lg-6' ?> reveal">
                <div class="ratio shadow rounded overflow-hidden mx-auto"
                     style="--bs-aspect-ratio: <?= $vertikal ? '177.78' : '56.25' ?>%;<?= $vertikal ? ' max-width: 320px;' : '' ?>">
                    <iframe src="https://www.youtube-nocookie.com/embed/<?= e($vid) ?>?rel=0"
                            title="<?= e($vJudul) ?>" loading="lazy"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
                <p class="text-center small mt-2 mb-0">
                    <a href="https://www.youtube.com/watch?v=<?= e($vid) ?>" target="_blank" rel="noopener noreferrer" class="text-muted">Tonton di YouTube</a>
                </p>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- AJAKAN BERTINDAK -->
<section class="container pb-4">
    <div class="cta-kopi text-center reveal">
        <h2 class="fw-bold">Siap menikmati secangkir Nusantara?</h2>
        <p class="mb-4">Pesan kopi favorit Anda sekarang atau kunjungi kami langsung di kedai.</p>
        <a href="pesan.php" class="btn btn-light btn-lg me-2">Pesan Sekarang</a>
        <a href="kontak.php" class="btn btn-outline-light btn-lg">Kunjungi Kami</a>
        <div class="mt-4"><?= ikonSosmed('terang') ?></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
