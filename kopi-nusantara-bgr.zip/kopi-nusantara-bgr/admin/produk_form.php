<?php
/** Admin: form tambah (Create) dan ubah (Update) produk */
require __DIR__ . '/_auth.php';

$id      = (int) ($_GET['id'] ?? 0);
$editing = $id > 0;
$judul   = $editing ? 'Ubah Produk' : 'Tambah Produk';
$aktif   = 'produk';

$kategoriList = ambilKategori();
$data = [
    'nama' => '', 'kategori_id' => 0, 'deskripsi' => '',
    'harga' => 0, 'stok' => 0, 'gambar' => 'produk-default.svg',
];

if ($editing) {
    $stmt = db()->prepare('SELECT * FROM produk WHERE id = ?');
    $stmt->execute([$id]);
    $data = $stmt->fetch();
    if (!$data) {
        setFlash('danger', 'Produk tidak ditemukan.');
        redirect('produk.php');
    }
}

/**
 * Simpan file gambar unggahan ke assets/img/uploads.
 * Mengembalikan nama file baru, atau null jika tidak ada unggahan.
 * Melempar RuntimeException bila file tidak valid.
 */
function simpanGambar(array $file): ?string
{
    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Gagal mengunggah gambar.');
    }
    if ($file['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException('Ukuran gambar maksimal 2 MB.');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $ekstensi = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if ($ekstensi === null) {
        throw new RuntimeException('Format gambar harus JPG, PNG, atau WEBP.');
    }

    $nama = 'produk-' . bin2hex(random_bytes(6)) . '.' . $ekstensi;
    $tujuan = __DIR__ . '/../assets/img/uploads/' . $nama;
    if (!move_uploaded_file($file['tmp_name'], $tujuan)) {
        throw new RuntimeException('Gambar tidak dapat disimpan. Periksa izin folder uploads.');
    }
    return $nama;
}

$galat = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $data['nama']        = trim($_POST['nama'] ?? '');
    $data['kategori_id'] = (int) ($_POST['kategori_id'] ?? 0);
    $data['deskripsi']   = trim($_POST['deskripsi'] ?? '');
    $data['harga']       = (int) ($_POST['harga'] ?? 0);
    $data['stok']        = (int) ($_POST['stok'] ?? -1);

    if ($data['nama'] === '')       { $galat['nama'] = 'Nama produk wajib diisi.'; }
    if ($data['kategori_id'] <= 0)  { $galat['kategori_id'] = 'Pilih kategori.'; }
    if ($data['deskripsi'] === '')  { $galat['deskripsi'] = 'Deskripsi wajib diisi.'; }
    if ($data['harga'] <= 0)        { $galat['harga'] = 'Harga harus lebih dari 0.'; }
    if ($data['stok'] < 0)          { $galat['stok'] = 'Stok tidak boleh negatif.'; }

    $gambarBaru = null;
    if (!$galat) {
        try {
            $gambarBaru = simpanGambar($_FILES['gambar'] ?? ['error' => UPLOAD_ERR_NO_FILE]);
        } catch (RuntimeException $ex) {
            $galat['gambar'] = $ex->getMessage();
        }
    }

    if (!$galat) {
        $gambarFinal = $gambarBaru ?? $data['gambar'];
        if ($editing) {
            // ---- UPDATE ----
            $stmt = db()->prepare(
                'UPDATE produk SET kategori_id=?, nama=?, deskripsi=?, harga=?, stok=?, gambar=? WHERE id=?'
            );
            $stmt->execute([$data['kategori_id'], $data['nama'], $data['deskripsi'],
                            $data['harga'], $data['stok'], $gambarFinal, $id]);
            setFlash('success', 'Produk berhasil diperbarui.');
        } else {
            // ---- CREATE ----
            $stmt = db()->prepare(
                'INSERT INTO produk (kategori_id, nama, deskripsi, harga, stok, gambar) VALUES (?,?,?,?,?,?)'
            );
            $stmt->execute([$data['kategori_id'], $data['nama'], $data['deskripsi'],
                            $data['harga'], $data['stok'], $gambarFinal]);
            setFlash('success', 'Produk berhasil ditambahkan.');
        }
        redirect('produk.php');
    }
}

require __DIR__ . '/_header.php';
?>
<div class="card border-0 shadow-sm p-4" style="max-width: 760px;">
    <form method="post" enctype="multipart/form-data" novalidate>
        <?= csrfField() ?>

        <div class="mb-3">
            <label for="nama" class="form-label">Nama produk</label>
            <input type="text" id="nama" name="nama" value="<?= e($data['nama']) ?>"
                   class="form-control<?= isset($galat['nama']) ? ' is-invalid' : '' ?>">
            <div class="invalid-feedback"><?= e($galat['nama'] ?? '') ?></div>
        </div>

        <div class="mb-3">
            <label for="kategori_id" class="form-label">Kategori</label>
            <select id="kategori_id" name="kategori_id"
                    class="form-select<?= isset($galat['kategori_id']) ? ' is-invalid' : '' ?>">
                <option value="">-- Pilih kategori --</option>
                <?php foreach ($kategoriList as $k): ?>
                    <option value="<?= (int) $k['id'] ?>" <?= (int) $data['kategori_id'] === (int) $k['id'] ? 'selected' : '' ?>>
                        <?= e($k['nama']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <div class="invalid-feedback"><?= e($galat['kategori_id'] ?? '') ?></div>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi</label>
            <textarea id="deskripsi" name="deskripsi" rows="3"
                      class="form-control<?= isset($galat['deskripsi']) ? ' is-invalid' : '' ?>"><?= e($data['deskripsi']) ?></textarea>
            <div class="invalid-feedback"><?= e($galat['deskripsi'] ?? '') ?></div>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label for="harga" class="form-label">Harga (Rp)</label>
                <input type="number" id="harga" name="harga" min="1" value="<?= (int) $data['harga'] ?>"
                       class="form-control<?= isset($galat['harga']) ? ' is-invalid' : '' ?>">
                <div class="invalid-feedback"><?= e($galat['harga'] ?? '') ?></div>
            </div>
            <div class="col-md-6">
                <label for="stok" class="form-label">Stok</label>
                <input type="number" id="stok" name="stok" min="0" value="<?= (int) $data['stok'] ?>"
                       class="form-control<?= isset($galat['stok']) ? ' is-invalid' : '' ?>">
                <div class="invalid-feedback"><?= e($galat['stok'] ?? '') ?></div>
            </div>
        </div>

        <div class="mb-4">
            <label for="gambar" class="form-label">Gambar produk (JPG/PNG/WEBP, maks. 2 MB)</label>
            <?php if ($editing): ?>
                <div class="mb-2">
                    <img class="admin-thumb" style="width:72px;height:72px" src="<?= e(urlGambar($data['gambar'], '../')) ?>" alt="Gambar saat ini">
                    <small class="text-muted ms-2">Kosongkan jika tidak ingin mengganti gambar.</small>
                </div>
            <?php endif; ?>
            <input type="file" id="gambar" name="gambar" accept="image/jpeg,image/png,image/webp"
                   class="form-control<?= isset($galat['gambar']) ? ' is-invalid' : '' ?>">
            <div class="invalid-feedback"><?= e($galat['gambar'] ?? '') ?></div>
        </div>

        <button type="submit" class="btn btn-kopi"><i class="bi bi-save"></i> Simpan</button>
        <a href="produk.php" class="btn btn-outline-secondary">Batal</a>
    </form>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
