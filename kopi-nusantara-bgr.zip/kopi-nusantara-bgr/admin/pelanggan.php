<?php
/** Admin: kelola data pelanggan (Read, Update, Delete) */
require __DIR__ . '/_auth.php';
$judul = 'Data Pelanggan';
$aktif = 'pelanggan';

$galat  = [];
$editId = (int) ($_GET['edit'] ?? 0);
$form   = ['nama' => '', 'alamat' => '', 'telepon' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $aksi = $_POST['aksi'] ?? '';
    $id   = (int) ($_POST['id'] ?? 0);

    if ($aksi === 'hapus') { // DELETE (pesanan pelanggan ikut terhapus via ON DELETE CASCADE)
        db()->prepare('DELETE FROM pelanggan WHERE id = ?')->execute([$id]);
        setFlash('success', 'Pelanggan dihapus.');
        redirect('pelanggan.php');
    }

    if ($aksi === 'ubah') { // UPDATE
        $form = [
            'nama'    => trim($_POST['nama'] ?? ''),
            'alamat'  => trim($_POST['alamat'] ?? ''),
            'telepon' => trim($_POST['telepon'] ?? ''),
        ];
        if (mb_strlen($form['nama']) < 3)    { $galat['nama'] = 'Nama minimal 3 karakter.'; }
        if (mb_strlen($form['alamat']) < 10) { $galat['alamat'] = 'Alamat minimal 10 karakter.'; }
        if (!preg_match('/^[0-9+\-\s]{8,20}$/', $form['telepon'])) { $galat['telepon'] = 'Telepon tidak valid.'; }

        if (!$galat) {
            db()->prepare('UPDATE pelanggan SET nama=?, alamat=?, telepon=? WHERE id=?')
                ->execute([$form['nama'], $form['alamat'], $form['telepon'], $id]);
            setFlash('success', 'Data pelanggan diperbarui.');
            redirect('pelanggan.php');
        }
        $editId = $id;
    }
}

// READ
$daftar = db()->query(
    'SELECT pl.*, COUNT(ps.id) AS jml_pesanan
     FROM pelanggan pl LEFT JOIN pesanan ps ON ps.pelanggan_id = pl.id
     GROUP BY pl.id ORDER BY pl.id DESC'
)->fetchAll();

if ($editId && !$galat) {
    foreach ($daftar as $pl) {
        if ((int) $pl['id'] === $editId) {
            $form = ['nama' => $pl['nama'], 'alamat' => $pl['alamat'], 'telepon' => $pl['telepon']];
        }
    }
}

require __DIR__ . '/_header.php';
?>
<?php if ($editId): ?>
    <div class="card border-0 shadow-sm p-3 mb-4" style="max-width: 700px;">
        <h2 class="h6 fw-bold">Ubah Pelanggan #<?= $editId ?></h2>
        <form method="post" novalidate>
            <?= csrfField() ?>
            <input type="hidden" name="aksi" value="ubah">
            <input type="hidden" name="id" value="<?= $editId ?>">
            <div class="mb-2">
                <input type="text" name="nama" placeholder="Nama" value="<?= e($form['nama']) ?>"
                       class="form-control<?= isset($galat['nama']) ? ' is-invalid' : '' ?>">
                <div class="invalid-feedback"><?= e($galat['nama'] ?? '') ?></div>
            </div>
            <div class="mb-2">
                <input type="text" name="telepon" placeholder="Telepon" value="<?= e($form['telepon']) ?>"
                       class="form-control<?= isset($galat['telepon']) ? ' is-invalid' : '' ?>">
                <div class="invalid-feedback"><?= e($galat['telepon'] ?? '') ?></div>
            </div>
            <div class="mb-2">
                <textarea name="alamat" rows="2" placeholder="Alamat"
                          class="form-control<?= isset($galat['alamat']) ? ' is-invalid' : '' ?>"><?= e($form['alamat']) ?></textarea>
                <div class="invalid-feedback"><?= e($galat['alamat'] ?? '') ?></div>
            </div>
            <button class="btn btn-kopi btn-sm">Simpan</button>
            <a href="pelanggan.php" class="btn btn-outline-secondary btn-sm">Batal</a>
        </form>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>#</th><th>Nama</th><th>Telepon</th><th>Alamat</th><th>Pesanan</th><th class="text-end">Aksi</th></tr>
            </thead>
            <tbody>
                <?php if (!$daftar): ?>
                    <tr><td colspan="6" class="text-center text-muted py-3">Belum ada pelanggan.</td></tr>
                <?php endif; ?>
                <?php foreach ($daftar as $pl): ?>
                    <tr>
                        <td><?= (int) $pl['id'] ?></td>
                        <td class="fw-semibold"><?= e($pl['nama']) ?></td>
                        <td><?= e($pl['telepon']) ?></td>
                        <td><?= e($pl['alamat']) ?></td>
                        <td><?= (int) $pl['jml_pesanan'] ?></td>
                        <td class="text-end text-nowrap">
                            <a href="pelanggan.php?edit=<?= (int) $pl['id'] ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i> Ubah</a>
                            <form method="post" class="d-inline"
                                  onsubmit="return confirm('Hapus pelanggan ini beserta pesanannya?');">
                                <?= csrfField() ?>
                                <input type="hidden" name="aksi" value="hapus">
                                <input type="hidden" name="id" value="<?= (int) $pl['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
