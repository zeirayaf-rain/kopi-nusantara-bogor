<?php
/**
 * Layout admin (bagian atas + sidebar).
 * Variabel: $judul (judul halaman), $aktif (menu aktif).
 */
$judul = $judul ?? 'Admin';
$aktif = $aktif ?? '';

$menuAdmin = [
    'dashboard' => ['index.php',     'bi-speedometer2', 'Dashboard'],
    'produk'    => ['produk.php',    'bi-box-seam',     'Produk'],
    'kategori'  => ['kategori.php',  'bi-tags',         'Kategori'],
    'pelanggan' => ['pelanggan.php', 'bi-people',       'Pelanggan'],
    'pesanan'   => ['pesanan.php',   'bi-receipt',      'Transaksi'],
    'pembayaran' => ['pembayaran.php', 'bi-wallet2',    'Struk &amp; Pembayaran'],
    'pesan'     => ['pesan_masuk.php', 'bi-envelope',   'Pesan Masuk'],
];

// Jumlah pesan kontak yang belum dibaca (aman bila tabel belum dibuat)
try {
    $belumDibaca = (int) db()->query('SELECT COUNT(*) FROM pesan_kontak WHERE dibaca = 0')->fetchColumn();
} catch (Throwable $ex) {
    $belumDibaca = 0;
}
// Pembayaran yang menunggu verifikasi (aman bila kolom belum dimigrasi)
try {
    $menungguBayar = (int) db()->query("SELECT COUNT(*) FROM pesanan WHERE status_bayar = 'menunggu' AND status <> 'batal'")->fetchColumn();
} catch (Throwable $ex) {
    $menungguBayar = 0;
}
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> | Admin Kopi Nusantara Bogor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="admin-body">
<div class="container-fluid">
    <div class="row">
        <aside class="col-md-3 col-lg-2 admin-sidebar p-3">
            <a href="index.php" class="d-block text-white fw-bold fs-5 text-decoration-none mb-3">
                <i class="bi bi-cup-hot-fill"></i> Kopi Admin
            </a>
            <ul class="nav nav-pills flex-column gap-1">
                <?php foreach ($menuAdmin as $kunci => [$url, $ikon, $label]): ?>
                    <li class="nav-item">
                        <a class="nav-link<?= $aktif === $kunci ? ' active' : '' ?>" href="<?= $url ?>">
                            <i class="bi <?= $ikon ?>"></i> <?= $label ?>
                            <?php if ($kunci === 'pesan' && $belumDibaca > 0): ?>
                                <span class="badge text-bg-danger ms-1"><?= $belumDibaca ?></span>
                            <?php endif; ?>
                            <?php if ($kunci === 'pembayaran' && $menungguBayar > 0): ?>
                                <span class="badge text-bg-danger ms-1"><?= $menungguBayar ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endforeach; ?>
                <li class="nav-item mt-3"><a class="nav-link" href="../index.php" target="_blank"><i class="bi bi-box-arrow-up-right"></i> Lihat Website</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-left"></i> Keluar</a></li>
            </ul>
            <div class="small text-white-50 mt-4">Masuk sebagai<br><strong class="text-white"><?= e($_SESSION['admin_nama'] ?? '') ?></strong></div>
        </aside>

        <main class="col-md-9 col-lg-10 p-4">
            <h1 class="h3 fw-bold mb-4"><?= e($judul) ?></h1>
            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['tipe']) ?> alert-dismissible fade show" role="alert">
                    <?= e($flash['pesan']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
                </div>
            <?php endif; ?>
