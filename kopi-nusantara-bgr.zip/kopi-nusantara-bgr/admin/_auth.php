<?php
/**
 * Pelindung halaman admin: sertakan file ini di setiap halaman admin
 * (kecuali login.php). Pengguna yang belum login dialihkan ke login.
 */
require_once __DIR__ . '/../includes/functions.php';

if (empty($_SESSION['admin_id'])) {
    redirect('login.php');
}
