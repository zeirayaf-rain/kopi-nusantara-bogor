<?php
/** Admin: CRUD kategori dalam satu halaman */
require __DIR__ . '/_auth.php';
$judul = 'Kelola Kategori';
$aktif = 'kategori';

$galat    = '';
$editId   = (int) ($_GET['edit'] ?? 0);
$editNama = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $aksi = $_POST['aksi'] ?? '';
    $id   = (int) ($_POST['id'] ?? 0);
    $nama = trim($_POST['nama'] ?? '');

    switch ($aksi) {
        case 'tambah': // CREATE
            if ($nama === '') {
                $galat = 'Nama kategori wajib diisi.';
                break;
            }
            try {
                db()->prepare('INSERT INTO kategori (nama) VALUES (?)')->execute([$nama]);
                setFlash('success', 'Kategori ditambahkan.');
                redirect('kategori.php');
            } catch (PDOException $ex) {
                $galat = 'Nama kategori sudah ada.';
            }
            break;

        case 'ubah': // UPDATE
            if ($nama === '') {
                $galat = 'Nama kategori wajib diisi.';
                $editId = $id;
                break;
            }
            try {
                db()->prepare('UPDATE kategori SET nama = ? WHERE id = ?')->execute([$nama, $id]);
                setFlash('success', 'Kategori diperbarui.');
                redirect('kategori.php');
            } catch (PDOException $ex) {
                $galat  = 'Nama kategori sudah ada.';
                $editId = $id;
            }
            break;

        case 'hapus': // DELETE
            try {
                db()->prepare('DELETE FROM kategori WHERE id = ?')->execute([$id]);
                setFlash('success', 'Kategori dihapus.');
            } catch (PDOException $ex) {
                // Kategori masih dipakai produk (foreign key RESTRICT)
                setFlash('danger', 'Kategori tidak bisa dihapus karena masih dipakai produk.');
            }
            redirect('kategori.php');
    }
}

// READ
$daftar = db()->query(
    'SELECT k.*, (SELECT COUNT(*) FROM produk p WHERE p.kategori_id = k.id) AS jml_produk
     FROM kategori k ORDER BY k.nama'
)->fetchAll();

foreach ($daftar as $k) {
    if ((int) $k['id'] === $editId) {
        $editNama = $k['nama'];
    }
}

require __DIR__ . '/_header.php';
?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm p-3">
            <h2 class="h6 fw-bold"><?= $editId ? 'Ubah Kategori' : 'Tambah Kategori' ?></h2>
            <?php if ($galat): ?><div class="alert alert-danger py-2"><?= e($galat) ?></div><?php endif; ?>
            <form method="post">
                <?= csrfField() ?>
                <input type="hidden" name="aksi" value="<?= $editId ? 'ubah' : 'tambah' ?>">
                <input type="hidden" name="id" value="<?= $editId ?>">
                <input type="text" name="nama" class="form-control mb-2" placeholder="Nama kategori"
                       value="<?= e($editNama) ?>" required>
                <button class="btn btn-kopi btn-sm"><?= $editId ? 'Simpan Perubahan' : 'Tambah' ?></button>
                <?php if ($editId): ?><a href="kategori.php" class="btn btn-outline-secondary btn-sm">Batal</a><?php endif; ?>
            </form>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light"><tr><th>Nama</th><th>Jumlah Produk</th><th class="text-end">Aksi</th></tr></thead>
                    <tbody>
                        <?php foreach ($daftar as $k): ?>
                            <tr>
                                <td class="fw-semibold"><?= e($k['nama']) ?></td>
                                <td><?= (int) $k['jml_produk'] ?></td>
                                <td class="text-end text-nowrap">
                                    <a href="kategori.php?edit=<?= (int) $k['id'] ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i> Ubah</a>
                                    <form method="post" class="d-inline" onsubmit="return confirm('Hapus kategori ini?');">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="aksi" value="hapus">
                                        <input type="hidden" name="id" value="<?= (int) $k['id'] ?>">
                                        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
