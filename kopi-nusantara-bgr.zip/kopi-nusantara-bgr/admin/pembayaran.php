<?php
/**
 * Admin: struk & pembayaran masuk.
 * Menampilkan semua struk beserta status bayarnya (belum / menunggu verifikasi / lunas),
 * bukti pembayaran dari pemesan, dan tombol konfirmasi.
 */
require __DIR__ . '/_auth.php';
$judul = 'Struk & Pembayaran';
$aktif = 'pembayaran';

$filter = $_GET['f'] ?? 'semua';
if (!in_array($filter, ['semua', 'menunggu', 'lunas', 'belum'], true)) {
    $filter = 'semua';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $aksi = $_POST['aksi'] ?? '';
    $id   = (int) ($_POST['id'] ?? 0);
    $pdo  = db();

    $stmt = $pdo->prepare('SELECT id, status, status_bayar, bukti_bayar FROM pesanan WHERE id = ?');
    $stmt->execute([$id]);
    $p = $stmt->fetch();

    if (!$p) {
        setFlash('danger', 'Pesanan tidak ditemukan.');
    } elseif ($aksi === 'lunas') {
        // Konfirmasi pembayaran; pesanan baru otomatis naik menjadi "diproses"
        $pdo->prepare("UPDATE pesanan SET status_bayar = 'lunas', dibayar_at = NOW(),
                           status = IF(status = 'baru', 'diproses', status)
                       WHERE id = ? AND status <> 'batal'")->execute([$id]);
        setFlash($p['status'] === 'batal' ? 'warning' : 'success',
            $p['status'] === 'batal' ? "Pesanan #{$id} sudah dibatalkan, tidak bisa dilunasi." : "Pembayaran pesanan #{$id} dikonfirmasi LUNAS.");
    } elseif ($aksi === 'tolak') {
        // Bukti tidak valid: kembali ke "belum dibayar", pemesan bisa unggah ulang
        hapusBukti((string) $p['bukti_bayar']);
        $pdo->prepare("UPDATE pesanan SET status_bayar = 'belum', bukti_bayar = '', dibayar_at = NULL WHERE id = ?")->execute([$id]);
        setFlash('warning', "Bukti pesanan #{$id} ditolak. Pemesan dapat mengunggah ulang.");
    } elseif ($aksi === 'buka') {
        $pdo->prepare("UPDATE pesanan SET status_bayar = 'belum', dibayar_at = NULL WHERE id = ?")->execute([$id]);
        setFlash('warning', "Status lunas pesanan #{$id} dibatalkan (kembali belum dibayar).");
    }
    redirect('pembayaran.php?f=' . urlencode($filter));
}

// Ringkasan
$ringkas = db()->query(
    "SELECT status_bayar, COUNT(*) AS n, COALESCE(SUM(total),0) AS nominal
     FROM pesanan WHERE status <> 'batal' GROUP BY status_bayar"
)->fetchAll(PDO::FETCH_UNIQUE);
$n   = static fn(string $k): int => (int) ($ringkas[$k]['n'] ?? 0);
$nom = static fn(string $k): int => (int) ($ringkas[$k]['nominal'] ?? 0);

// Daftar struk
$sql = 'SELECT ps.*, pl.nama AS pelanggan, pl.telepon, pr.nama AS produk
        FROM pesanan ps
        JOIN pelanggan pl ON pl.id = ps.pelanggan_id
        JOIN produk pr ON pr.id = ps.produk_id';
$param = [];
if ($filter !== 'semua') {
    $sql .= ' WHERE ps.status_bayar = ?';
    $param[] = $filter;
}
// Menunggu verifikasi tampil paling atas
$sql .= " ORDER BY (ps.status_bayar = 'menunggu') DESC, ps.id DESC";
$stmt = db()->prepare($sql);
$stmt->execute($param);
$daftar = $stmt->fetchAll();

$tab = ['semua' => 'Semua', 'menunggu' => 'Menunggu verifikasi', 'belum' => 'Belum dibayar', 'lunas' => 'Lunas'];

require __DIR__ . '/_header.php';
?>
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3">
            <div class="text-muted small">Menunggu verifikasi</div>
            <div class="h3 fw-bold mb-0"><?= $n('menunggu') ?> <small class="fs-6 text-muted"><?= rupiah($nom('menunggu')) ?></small></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3">
            <div class="text-muted small">Belum dibayar</div>
            <div class="h3 fw-bold mb-0"><?= $n('belum') ?> <small class="fs-6 text-muted"><?= rupiah($nom('belum')) ?></small></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3">
            <div class="text-muted small">Sudah dibayar (lunas)</div>
            <div class="h3 fw-bold text-success mb-0"><?= $n('lunas') ?> <small class="fs-6 text-muted"><?= rupiah($nom('lunas')) ?></small></div>
        </div>
    </div>
</div>

<ul class="nav nav-pills mb-3 gap-1">
    <?php foreach ($tab as $kunci => $nama): ?>
        <li class="nav-item"><a class="nav-link py-1<?= $filter === $kunci ? ' active' : '' ?>" href="pembayaran.php?f=<?= e($kunci) ?>"><?= e($nama) ?></a></li>
    <?php endforeach; ?>
</ul>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>No. Struk</th><th>Pemesan</th><th>Produk</th><th>Total</th><th>Metode</th><th>Pembayaran</th><th>Bukti</th><th class="text-end">Aksi</th></tr>
            </thead>
            <tbody>
                <?php if (!$daftar): ?>
                    <tr><td colspan="8" class="text-center text-muted py-3">Belum ada struk pada filter ini.</td></tr>
                <?php endif; ?>
                <?php foreach ($daftar as $r): [$lb, $wb] = infoBayar($r['status_bayar']); $batal = $r['status'] === 'batal'; ?>
                    <tr<?= $batal ? ' class="text-muted"' : '' ?>>
                        <td class="text-nowrap">
                            <strong><?= e(noStruk($r)) ?></strong><br>
                            <small class="text-muted"><?= e(date('d/m/Y H:i', strtotime($r['created_at']))) ?></small>
                        </td>
                        <td><?= e($r['pelanggan']) ?><br><small class="text-muted"><?= e($r['telepon']) ?></small></td>
                        <td><?= e($r['produk']) ?> &times; <?= (int) $r['jumlah'] ?><?= $batal ? ' <span class="badge text-bg-danger">Batal</span>' : '' ?></td>
                        <td class="text-nowrap"><?= rupiah((int) $r['total']) ?></td>
                        <td class="text-nowrap"><?= e(labelMetode($r)) ?></td>
                        <td>
                            <span class="badge text-bg-<?= e($wb) ?>"><?= e($lb) ?></span>
                            <?php if ($r['status_bayar'] === 'lunas' && $r['dibayar_at']): ?>
                                <br><small class="text-muted"><?= e(date('d/m/Y H:i', strtotime($r['dibayar_at']))) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($r['bukti_bayar'] !== ''): ?>
                                <a href="../assets/img/uploads/bukti/<?= e($r['bukti_bayar']) ?>" target="_blank" rel="noopener">
                                    <img src="../assets/img/uploads/bukti/<?= e($r['bukti_bayar']) ?>" alt="Bukti pesanan #<?= (int) $r['id'] ?>"
                                         style="width:48px;height:48px;object-fit:cover;border-radius:.4rem;border:1px solid #ddd">
                                </a>
                            <?php else: ?>
                                <span class="text-muted small">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end text-nowrap">
                            <a class="btn btn-sm btn-outline-secondary" href="../struk.php?id=<?= (int) $r['id'] ?>" target="_blank" rel="noopener" title="Lihat struk"><i class="bi bi-receipt"></i></a>
                            <?php if ($r['status_bayar'] !== 'lunas' && !$batal): ?>
                                <form method="post" class="d-inline" onsubmit="return confirm('Konfirmasi pembayaran pesanan #<?= (int) $r['id'] ?> sebagai LUNAS?');">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="aksi" value="lunas">
                                    <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                    <button class="btn btn-sm btn-success" title="Tandai lunas"><i class="bi bi-check2-circle"></i> Lunas</button>
                                </form>
                            <?php endif; ?>
                            <?php if ($r['status_bayar'] === 'menunggu'): ?>
                                <form method="post" class="d-inline" onsubmit="return confirm('Tolak bukti pembayaran ini?');">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="aksi" value="tolak">
                                    <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger" title="Tolak bukti"><i class="bi bi-x-circle"></i></button>
                                </form>
                            <?php elseif ($r['status_bayar'] === 'lunas'): ?>
                                <form method="post" class="d-inline" onsubmit="return confirm('Batalkan status lunas pesanan #<?= (int) $r['id'] ?>?');">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="aksi" value="buka">
                                    <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                    <button class="btn btn-sm btn-outline-warning" title="Batalkan lunas"><i class="bi bi-arrow-counterclockwise"></i></button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
