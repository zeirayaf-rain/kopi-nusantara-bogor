<?php
/** Dashboard admin: ringkasan data */
require __DIR__ . '/_auth.php';
$judul = 'Dashboard';
$aktif = 'dashboard';

$pdo = db();
$ringkasan = [
    ['Produk',        (int) $pdo->query('SELECT COUNT(*) FROM produk')->fetchColumn(),    'bi-box-seam', 'produk.php'],
    ['Kategori',      (int) $pdo->query('SELECT COUNT(*) FROM kategori')->fetchColumn(),  'bi-tags',     'kategori.php'],
    ['Pelanggan',     (int) $pdo->query('SELECT COUNT(*) FROM pelanggan')->fetchColumn(), 'bi-people',   'pelanggan.php'],
    ['Transaksi',     (int) $pdo->query('SELECT COUNT(*) FROM pesanan')->fetchColumn(),   'bi-receipt',  'pesanan.php'],
];
try {
    $ringkasan[] = ['Pesan Belum Dibaca', (int) $pdo->query('SELECT COUNT(*) FROM pesan_kontak WHERE dibaca = 0')->fetchColumn(), 'bi-envelope', 'pesan_masuk.php'];
} catch (Throwable $ex) {
    // tabel pesan_kontak belum dibuat
}
$pendapatan = (int) $pdo->query("SELECT COALESCE(SUM(total),0) FROM pesanan WHERE status_bayar = 'lunas' AND status <> 'batal'")->fetchColumn();
$menungguBayarRp = (int) $pdo->query("SELECT COALESCE(SUM(total),0) FROM pesanan WHERE status_bayar <> 'lunas' AND status <> 'batal'")->fetchColumn();

$terbaru = $pdo->query(
    'SELECT ps.id, ps.total, ps.status, ps.status_bayar, ps.created_at, pl.nama AS pelanggan, pr.nama AS produk
     FROM pesanan ps
     JOIN pelanggan pl ON pl.id = ps.pelanggan_id
     JOIN produk pr ON pr.id = ps.produk_id
     ORDER BY ps.id DESC LIMIT 5'
)->fetchAll();

require __DIR__ . '/_header.php';
?>
<div class="row g-3 mb-4">
    <?php foreach ($ringkasan as [$label, $jumlah, $ikon, $url]): ?>
        <div class="col-6 col-xl-3">
            <a href="<?= $url ?>" class="text-decoration-none">
                <div class="card border-0 shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                    <div class="ikon-bulat"><i class="bi <?= $ikon ?>"></i></div>
                    <div>
                        <div class="h3 fw-bold mb-0 text-dark"><?= $jumlah ?></div>
                        <div class="text-muted small"><?= $label ?></div>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
</div>

<div class="card border-0 shadow-sm p-3 mb-4">
    <div class="text-muted small">Pendapatan masuk (pembayaran lunas)</div>
    <div class="h3 fw-bold text-aksen mb-0"><?= rupiah($pendapatan) ?></div>
    <div class="small text-muted mt-1">Belum lunas: <?= rupiah($menungguBayarRp) ?> &middot; <a href="pembayaran.php">lihat struk &amp; pembayaran</a></div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-bold">Pesanan Terbaru</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>#</th><th>Pelanggan</th><th>Produk</th><th>Total</th><th>Bayar</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php if (!$terbaru): ?>
                    <tr><td colspan="6" class="text-center text-muted py-3">Belum ada pesanan.</td></tr>
                <?php endif; ?>
                <?php foreach ($terbaru as $r): [$label, $warna] = infoStatus($r['status']); ?>
                    <tr>
                        <td><?= (int) $r['id'] ?></td>
                        <td><?= e($r['pelanggan']) ?></td>
                        <td><?= e($r['produk']) ?></td>
                        <td><?= rupiah((int) $r['total']) ?></td>
                        <td><?php [$lb, $wb] = infoBayar($r['status_bayar']); ?><span class="badge text-bg-<?= e($wb) ?>"><?= e($lb) ?></span></td>
                        <td><span class="badge text-bg-<?= $warna ?>"><?= $label ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
