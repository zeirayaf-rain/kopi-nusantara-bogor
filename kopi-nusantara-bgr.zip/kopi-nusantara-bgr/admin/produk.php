<?php
/** Admin: daftar produk (Read) + hapus (Delete). Tambah/ubah ada di produk_form.php */
require __DIR__ . '/_auth.php';
$judul = 'Kelola Produk';
$aktif = 'produk';

// ---- DELETE ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'hapus') {
    csrfCheck();
    $id = (int) ($_POST['id'] ?? 0);
    try {
        $stmt = db()->prepare('DELETE FROM produk WHERE id = ?');
        $stmt->execute([$id]);
        setFlash('success', 'Produk berhasil dihapus.');
    } catch (PDOException $ex) {
        setFlash('danger', 'Produk gagal dihapus.');
    }
    redirect('produk.php');
}

// ---- READ ----
$daftar = ambilProduk();

require __DIR__ . '/_header.php';
?>
<div class="mb-3">
    <a href="produk_form.php" class="btn btn-kopi"><i class="bi bi-plus-lg"></i> Tambah Produk</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>Gambar</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th class="text-end">Aksi</th></tr>
            </thead>
            <tbody>
                <?php if (!$daftar): ?>
                    <tr><td colspan="6" class="text-center text-muted py-3">Belum ada produk.</td></tr>
                <?php endif; ?>
                <?php foreach ($daftar as $p): ?>
                    <tr>
                        <td><img class="admin-thumb" src="<?= e(urlGambar($p['gambar'], '../')) ?>" alt=""></td>
                        <td class="fw-semibold"><?= e($p['nama']) ?></td>
                        <td><?= e($p['kategori']) ?></td>
                        <td><?= rupiah((int) $p['harga']) ?></td>
                        <td>
                            <?php if ((int) $p['stok'] <= 5): ?>
                                <span class="badge text-bg-danger"><?= (int) $p['stok'] ?></span>
                            <?php else: ?>
                                <?= (int) $p['stok'] ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-end text-nowrap">
                            <a href="produk_form.php?id=<?= (int) $p['id'] ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i> Ubah
                            </a>
                            <form method="post" class="d-inline"
                                  onsubmit="return confirm('Hapus produk ini? Pesanan terkait ikut terhapus.');">
                                <?= csrfField() ?>
                                <input type="hidden" name="aksi" value="hapus">
                                <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
