<?php
/** Admin: kelola transaksi/pesanan (Read, Update status, Delete) */
require __DIR__ . '/_auth.php';
$judul = 'Transaksi / Pesanan';
$aktif = 'pesanan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $aksi = $_POST['aksi'] ?? '';
    $id   = (int) ($_POST['id'] ?? 0);

    if ($aksi === 'status') { // UPDATE status
        $status = $_POST['status'] ?? '';
        if (in_array($status, STATUS_PESANAN, true)) {
            db()->prepare('UPDATE pesanan SET status = ? WHERE id = ?')->execute([$status, $id]);
            setFlash('success', "Status pesanan #{$id} diubah.");
        }
    } elseif ($aksi === 'hapus') { // DELETE
        $b = db()->prepare('SELECT bukti_bayar FROM pesanan WHERE id = ?');
        $b->execute([$id]);
        hapusBukti((string) $b->fetchColumn()); // hapus juga file bukti pembayaran
        db()->prepare('DELETE FROM pesanan WHERE id = ?')->execute([$id]);
        setFlash('success', "Pesanan #{$id} dihapus.");
    }
    redirect('pesanan.php');
}

// READ
$daftar = db()->query(
    'SELECT ps.*, pl.nama AS pelanggan, pl.telepon, pr.nama AS produk
     FROM pesanan ps
     JOIN pelanggan pl ON pl.id = ps.pelanggan_id
     JOIN produk pr ON pr.id = ps.produk_id
     ORDER BY ps.id DESC'
)->fetchAll();

require __DIR__ . '/_header.php';
?>
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>#</th><th>Tanggal</th><th>Pelanggan</th><th>Produk</th><th>Jml</th><th>Total</th><th>Bayar</th><th>Status</th><th class="text-end">Aksi</th></tr>
            </thead>
            <tbody>
                <?php if (!$daftar): ?>
                    <tr><td colspan="9" class="text-center text-muted py-3">Belum ada transaksi.</td></tr>
                <?php endif; ?>
                <?php foreach ($daftar as $r): [$label, $warna] = infoStatus($r['status']); ?>
                    <tr>
                        <td><?= (int) $r['id'] ?></td>
                        <td class="text-nowrap"><?= e(date('d/m/Y H:i', strtotime($r['created_at']))) ?></td>
                        <td><?= e($r['pelanggan']) ?><br><small class="text-muted"><?= e($r['telepon']) ?></small></td>
                        <td><?= e($r['produk']) ?></td>
                        <td><?= (int) $r['jumlah'] ?></td>
                        <td class="text-nowrap"><?= rupiah((int) $r['total']) ?></td>
                        <td>
                            <?php [$lb, $wb] = infoBayar($r['status_bayar']); ?>
                            <span class="badge text-bg-<?= e($wb) ?>"><?= e($lb) ?></span><br>
                            <small class="text-muted"><?= e(labelMetode($r)) ?></small>
                        </td>
                        <td>
                            <form method="post" class="d-flex gap-1">
                                <?= csrfField() ?>
                                <input type="hidden" name="aksi" value="status">
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <select name="status" class="form-select form-select-sm" style="min-width:110px">
                                    <?php foreach (STATUS_PESANAN as $s): ?>
                                        <option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button class="btn btn-sm btn-outline-primary" title="Simpan status"><i class="bi bi-check2"></i></button>
                            </form>
                        </td>
                        <td class="text-end text-nowrap">
                            <a class="btn btn-sm btn-outline-secondary" href="../struk.php?id=<?= (int) $r['id'] ?>" target="_blank" rel="noopener" title="Lihat struk"><i class="bi bi-receipt"></i></a>
                            <form method="post" class="d-inline" onsubmit="return confirm('Hapus pesanan ini?');">
                                <?= csrfField() ?>
                                <input type="hidden" name="aksi" value="hapus">
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
