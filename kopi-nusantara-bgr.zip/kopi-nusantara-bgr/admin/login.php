<?php
/** Halaman login admin */
require_once __DIR__ . '/../includes/functions.php';

if (!empty($_SESSION['admin_id'])) {
    redirect('index.php');
}

$galat = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT * FROM admin WHERE username = ?');
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        session_regenerate_id(true); // cegah session fixation
        $_SESSION['admin_id']   = (int) $admin['id'];
        $_SESSION['admin_nama'] = $admin['nama_lengkap'];
        redirect('index.php');
    }
    $galat = 'Username atau password salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin | Kopi NusantaraBogor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="admin-body d-flex align-items-center min-vh-100">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-9 col-md-6 col-lg-4">
            <div class="card border-0 shadow p-4">
                <div class="text-center mb-3">
                    <div class="ikon-bulat mx-auto mb-2"><i class="bi bi-cup-hot-fill"></i></div>
                    <h1 class="h4 fw-bold mb-0">Login Admin</h1>
                    <small class="text-muted">Kopi NusantaraBogor</small>
                </div>

                <?php if ($galat): ?>
                    <div class="alert alert-danger py-2"><?= e($galat) ?></div>
                <?php endif; ?>

                <form method="post" autocomplete="off">
                    <?= csrfField() ?>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" id="username" name="username" class="form-control" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-kopi w-100">Masuk</button>
                </form>
                <a href="../index.php" class="d-block text-center mt-3 small">&larr; Kembali ke website</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
