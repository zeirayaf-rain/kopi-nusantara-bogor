<?php
/** Admin: pesan masuk dari form Kontak (Read, tandai dibaca, Delete) */
require __DIR__ . '/_auth.php';
$judul = 'Pesan Masuk';
$aktif = 'pesan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $aksi = $_POST['aksi'] ?? '';
    $id   = (int) ($_POST['id'] ?? 0);

    if ($aksi === 'dibaca' || $aksi === 'belum') { // UPDATE
        db()->prepare('UPDATE pesan_kontak SET dibaca = ? WHERE id = ?')->execute([$aksi === 'dibaca' ? 1 : 0, $id]);
    } elseif ($aksi === 'semua') {
        db()->exec('UPDATE pesan_kontak SET dibaca = 1');
        setFlash('success', 'Semua pesan ditandai sudah dibaca.');
    } elseif ($aksi === 'hapus') { // DELETE
        db()->prepare('DELETE FROM pesan_kontak WHERE id = ?')->execute([$id]);
        setFlash('success', 'Pesan dihapus.');
    }
    redirect('pesan_masuk.php');
}

// READ
$tabelAda = true;
try {
    $daftar = db()->query('SELECT * FROM pesan_kontak ORDER BY id DESC')->fetchAll();
} catch (Throwable $ex) {
    $tabelAda = false;
    $daftar = [];
}

require __DIR__ . '/_header.php';
?>
<?php if (!$tabelAda): ?>
    <div class="alert alert-warning">Tabel <code>pesan_kontak</code> belum ada. Jalankan <code>database/migrasi_v13.sql</code> di phpMyAdmin.</div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <span class="text-muted small"><?= count($daftar) ?> pesan, <?= (int) $belumDibaca ?> belum dibaca</span>
    <?php if ($belumDibaca > 0): ?>
        <form method="post">
            <?= csrfField() ?>
            <input type="hidden" name="aksi" value="semua">
            <button class="btn btn-sm btn-outline-primary"><i class="bi bi-check2-all"></i> Tandai semua dibaca</button>
        </form>
    <?php endif; ?>
</div>

<?php if (!$daftar && $tabelAda): ?>
    <div class="card border-0 shadow-sm p-4 text-center text-muted">Belum ada pesan masuk dari form Kontak.</div>
<?php endif; ?>

<?php foreach ($daftar as $m): ?>
    <div class="card border-0 shadow-sm mb-3<?= $m['dibaca'] ? '' : ' border-start border-4 border-danger' ?>">
        <div class="card-body">
            <div class="d-flex justify-content-between flex-wrap gap-2">
                <div>
                    <strong><?= e($m['nama']) ?></strong>
                    <?php if (!$m['dibaca']): ?><span class="badge text-bg-danger ms-1">Baru</span><?php endif; ?>
                    <div class="small text-muted">
                        <a href="mailto:<?= e($m['email']) ?>"><?= e($m['email']) ?></a>
                        &middot; <?= e(date('d/m/Y H:i', strtotime($m['created_at']))) ?>
                    </div>
                </div>
                <div class="d-flex gap-1 align-items-start">
                    <a class="btn btn-sm btn-outline-secondary" href="mailto:<?= e($m['email']) ?>?subject=<?= rawurlencode('Balasan dari Kopi NusantaraBogor') ?>" title="Balas lewat email"><i class="bi bi-reply"></i></a>
                    <form method="post">
                        <?= csrfField() ?>
                        <input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
                        <input type="hidden" name="aksi" value="<?= $m['dibaca'] ? 'belum' : 'dibaca' ?>">
                        <button class="btn btn-sm btn-outline-primary" title="<?= $m['dibaca'] ? 'Tandai belum dibaca' : 'Tandai sudah dibaca' ?>">
                            <i class="bi <?= $m['dibaca'] ? 'bi-envelope' : 'bi-envelope-open' ?>"></i>
                        </button>
                    </form>
                    <form method="post" onsubmit="return confirm('Hapus pesan ini?');">
                        <?= csrfField() ?>
                        <input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
                        <input type="hidden" name="aksi" value="hapus">
                        <button class="btn btn-sm btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                    </form>
                </div>
            </div>
            <p class="mb-0 mt-3" style="white-space:pre-line"><?= e($m['pesan']) ?></p>
        </div>
    </div>
<?php endforeach; ?>

<?php require __DIR__ . '/_footer.php'; ?>
