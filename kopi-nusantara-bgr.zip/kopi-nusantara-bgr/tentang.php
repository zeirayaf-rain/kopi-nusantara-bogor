<?php
/** Halaman Tentang Kami */
$judul = 'Tentang Kami';
$aktif = 'tentang';
require __DIR__ . '/includes/header.php';

$galeri   = daftarGaleri();
$kategori = array_values(array_unique(array_column($galeri, 'kategori')));
?>

<header class="page-header text-center" style="<?= e(bannerStyle('kopi-4.jpg')) ?>">
    <div class="container">
        <h1 class="fw-bold animate__animated animate__fadeInDown">Tentang Kami</h1>
        <p class="mb-0">Cerita di balik setiap cangkir Kopi Nusantara Bogor</p>
    </div>
</header>

<main class="container py-5">
    <div class="row align-items-center g-5">
        <div class="col-lg-6 reveal">
            <img src="<?= e(urlFoto('kopi-6.jpg', 1200)) ?>" class="img-fluid rounded shadow-sm" alt="Barista Kopi NusantaraBogor menggiling biji kopi" loading="lazy">
        </div>
        <div class="col-lg-6 reveal">
            <h2 class="fw-bold">Dari Petani, untuk Pecinta Kopi</h2>
            <p>Kopi Nusantara Bogor adalah coffeeshop yang dikembangkan oleh Keenan Technology StartUp.
                Kami berfokus pada penjualan kopi kemasan dan minuman kopi siap saji dengan bahan baku
                dari petani lokal di berbagai daerah Indonesia. KOPI adalah Kebersamaan, Originalitas, Pengabdian, dan Integritas.
Kami bekerja langsung dengan petani lokal di Toraja, Gayo, dan Flores untuk memastikan setiap biji dipetik dengan hati. Kami tidak hanya menyeduh kopi, kami menyeduh kebanggaan Nusantara.</p>
            <p>Setiap biji kopi dipilih, disangrai, dan dikemas dengan teliti agar aroma dan rasa
                khasnya sampai utuh ke tangan Anda. Dari petani untuk penikmat.</p>
        </div>
    </div>

    <div class="row g-4 mt-4">
        <?php
        $nilai = [
            ['bi-eye',   'Visi',  'Menjadi merek kopi lokal yang dikenal dan dicintai di seluruh Indonesia.'],
            ['bi-bullseye', 'Misi', 'Mengangkat kopi petani lokal, menjaga kualitas, dan melayani dengan ramah.'],
            ['bi-heart', 'Nilai',  'Kejujuran, kualitas, keberlanjutan, dan kebersamaan.'],
        ];
        foreach ($nilai as [$ikon, $judulN, $teks]): ?>
            <div class="col-md-4 reveal">
                <div class="card h-100 border-0 shadow-sm text-center p-4">
                    <div class="ikon-bulat mx-auto mb-3"><i class="bi <?= $ikon ?>"></i></div>
                    <h3 class="h5 fw-bold"><?= $judulN ?></h3>
                    <p class="text-muted mb-0"><?= $teks ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <h2 class="fw-bold text-center mt-5 mb-1">Layanan & Kenyamanan</h2>
    <p class="text-center text-muted mb-4">Selain kopi, ini yang bisa Anda nikmati di sini</p>
    <div class="row g-4">
        <?php
        $layanan = [
            ['bi-cup-hot', 'Dine-in Nyaman', 'Duduk santai dengan musik pelan, cocok untuk mengobrol atau menyendiri.'],
            ['bi-laptop', 'Kerja dari Kedai', 'Wi-Fi, colokan listrik di banyak meja, dan pencahayaan yang nyaman.'],
            ['bi-mortarboard', 'Kelas Seduh Manual', 'Belajar teknik dasar espresso dan V60 bersama barista kami.'],
            ['bi-truck-front', 'Katering Kopi', 'Barista dan mesin espresso hadir di acara kantor, keluarga, atau komunitas.'],
        ];
        foreach ($layanan as [$ikon, $judulL, $teks]): ?>
            <div class="col-sm-6 col-lg-3 reveal">
                <div class="card h-100 border-0 shadow-sm p-4">
                    <div class="ikon-bulat mb-3"><i class="bi <?= $ikon ?>"></i></div>
                    <h3 class="h6 fw-bold"><?= $judulL ?></h3>
                    <p class="text-muted small mb-0"><?= $teks ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <section id="galeri" class="mt-5 pt-4">
        <h2 class="fw-bold text-center mb-1">Galeri</h2>
        <p class="text-center text-muted mb-4">Suasana, seduhan, barista, dan biji kopi di Kopi NusantaraBogor</p>
        <div class="galeri-grid" id="gridGaleri">
            <?php foreach ($galeri as $g): ?>
                <?php include __DIR__ . '/includes/galeri_item.php'; ?>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
