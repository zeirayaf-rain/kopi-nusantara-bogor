<?php
/** Halaman Kontak (form pesan sederhana dengan validasi sisi server) */
$judul = 'Kontak';
$aktif = 'kontak';
require __DIR__ . '/includes/header.php';

$galat  = [];
$input  = ['nama' => '', 'email' => '', 'pesan' => ''];
$sukses = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    foreach ($input as $kunci => $_) {
        $input[$kunci] = trim($_POST[$kunci] ?? '');
    }

    if ($input['nama'] === '') {
        $galat['nama'] = 'Nama wajib diisi.';
    }
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        $galat['email'] = 'Format email tidak valid.';
    }
    if (mb_strlen($input['pesan']) < 10) {
        $galat['pesan'] = 'Pesan minimal 10 karakter.';
    }

    if (!$galat) {
        // Simpan ke database; admin membacanya di menu Pesan Masuk
        try {
            db()->prepare('INSERT INTO pesan_kontak (nama, email, pesan) VALUES (?, ?, ?)')
                ->execute([mb_substr($input['nama'], 0, 100), mb_substr($input['email'], 0, 150), $input['pesan']]);
            $sukses = true;
            $input  = ['nama' => '', 'email' => '', 'pesan' => ''];
        } catch (Throwable $ex) {
            $galat['umum'] = 'Pesan belum bisa disimpan. Coba lagi beberapa saat lagi.';
        }
    }
}
?>

<header class="page-header text-center" style="<?= e(bannerStyle('kopi-10.jpg')) ?>">
    <div class="container">
        <h1 class="fw-bold animate__animated animate__fadeInDown">Hubungi Kami</h1>
        <p class="mb-0">Ada pertanyaan atau masukan? Kami senang mendengarnya</p>
    </div>
</header>

<main class="container py-5">
    <div class="row g-5">
        <div class="col-lg-5 reveal">
            <h2 class="h4 fw-bold mb-3">Informasi Kontak</h2>
            <ul class="list-unstyled">
                <li class="mb-3"><i class="bi bi-geo-alt-fill text-aksen"></i> Jl. Kopi No. 1, Bogor, Jawa Barat</li>
                <li class="mb-3"><i class="bi bi-telephone-fill text-aksen"></i> 0812-0000-1234</li>
                <li class="mb-3"><i class="bi bi-envelope-fill text-aksen"></i> halo@kopinusantarabogor.test</li>
                <li class="mb-3"><i class="bi bi-clock-fill text-aksen"></i> Senin - Minggu, 09.00 - 22.00 WIB</li>
            </ul>
        </div>
        <div class="col-lg-7 reveal">
            <?php if ($sukses): ?>
                <div class="alert alert-success">Terima kasih! Pesan Anda sudah kami terima.</div>
            <?php endif; ?>

            <?php if (isset($galat['umum'])): ?>
                <div class="alert alert-danger"><?= e($galat['umum']) ?></div>
            <?php endif; ?>

            <form method="post" novalidate class="card border-0 shadow-sm p-4">
                <?= csrfField() ?>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" id="nama" name="nama" value="<?= e($input['nama']) ?>"
                           class="form-control<?= isset($galat['nama']) ? ' is-invalid' : '' ?>">
                    <div class="invalid-feedback"><?= e($galat['nama'] ?? '') ?></div>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" value="<?= e($input['email']) ?>"
                           class="form-control<?= isset($galat['email']) ? ' is-invalid' : '' ?>">
                    <div class="invalid-feedback"><?= e($galat['email'] ?? '') ?></div>
                </div>
                <div class="mb-3">
                    <label for="pesan" class="form-label">Pesan</label>
                    <textarea id="pesan" name="pesan" rows="4"
                              class="form-control<?= isset($galat['pesan']) ? ' is-invalid' : '' ?>"><?= e($input['pesan']) ?></textarea>
                    <div class="invalid-feedback"><?= e($galat['pesan'] ?? '') ?></div>
                </div>
                <button type="submit" class="btn btn-kopi">Kirim Pesan</button>
            </form>
        </div>
    </div>

    <div class="row g-4 mt-2">
        <div class="col-lg-7 reveal">
            <div class="ratio rounded overflow-hidden shadow-sm peta-kontak">
                <iframe title="Peta lokasi Kopi NusantaraBogor" loading="lazy"
                        src="https://www.google.com/maps?q=Bogor,Jawa+Barat&amp;output=embed"
                        referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
            </div>
        </div>
        <div class="col-lg-5 reveal">
            <h2 class="h4 fw-bold mb-1">Ikuti Kami</h2>
            <p class="text-muted small mb-3">Jangan cuma kangen rasanya, ikuti keseharian kami.
Ada promo seduh, cerita petani, dan spot ngopi baru setiap minggunya, serta Promo pembelian, menu baru, dan kabar terbaru dari kedai.</p>
            <div class="d-grid gap-2">
                <?php foreach (SOSMED as [$nama, $ikon, $url]): ?>
                    <a href="<?= e($url) ?>" target="_blank" rel="noopener noreferrer" class="sosmed-kartu">
                        <span class="sosmed-ikon"><i class="bi <?= e($ikon) ?>"></i></span>
                        <span class="sosmed-teks">
                            <strong><?= e($nama) ?></strong>
                            <small>@kopinusantarabogor</small>
                        </span>
                        <i class="bi bi-box-arrow-up-right ms-auto text-muted"></i>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
